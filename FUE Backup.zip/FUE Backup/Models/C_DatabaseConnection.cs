﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.Models
{
    public class C_DatabaseConnection
    {
        public int Connection_k { get; set; }
        public string DataSource { get; set; }
        public string Catalog { get; set; }
        public string User_id { get; set; }
        public string Password { get; set; }
        public string Type { get; set; }
    }
}