﻿using FUE.Web.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace FUE.Web.DataAccess
{
    public class dalGetFTP
    {
        EFDBContext _db = new EFDBContext();
        public string[] GetFileList()
        {
            string[] downloadFiles;
            StringBuilder result = new StringBuilder();
            FtpWebRequest reqFTP;
            try
            {
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + "test.rebex.net" + "/"));
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential("demo", "password");
                reqFTP.Method = WebRequestMethods.Ftp.ListDirectory;
                WebResponse response = reqFTP.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());

                string line = reader.ReadLine();
                while (line != null)
                {
                    result.Append(line);
                    result.Append("\n");
                    line = reader.ReadLine();
                }
                // to remove the trailing '\n'
                result.Remove(result.ToString().LastIndexOf('\n'), 1);
                reader.Close();
                response.Close();

                return result.ToString().Split('\n');
            }
            catch (Exception ex)
            {
                //System.Windows.Forms.MessageBox.Show(ex.Message);
                downloadFiles = null;
                return downloadFiles;
            }
        }


        public void GETFTPFILE(string FtpURL, string UserName, string Password, string DownloadPath)
        {
            FtpURL = "ftp://" + FtpURL + "/";

            FtpWebRequest ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri(FtpURL));
            ftpRequest.Credentials = new NetworkCredential(UserName, Password);
            ftpRequest.Method = WebRequestMethods.Ftp.ListDirectory;
            FtpWebResponse response = (FtpWebResponse)ftpRequest.GetResponse();
            StreamReader streamReader = new StreamReader(response.GetResponseStream());
            List<string> directories = new List<string>();

            string line = streamReader.ReadLine();
            while (!string.IsNullOrEmpty(line))
            {
                directories.Add(line);
                line = streamReader.ReadLine();
            }
            streamReader.Close();


            using (WebClient ftpClient = new WebClient())
            {
                ftpClient.Credentials = new System.Net.NetworkCredential(UserName, Password);

                for (int i = 0; i <= directories.Count - 1; i++)
                {
                    if (directories[i].Contains("."))
                    {
                            string path = FtpURL + directories[i].ToString();
                            string trnsfrpth = @"" + DownloadPath + "" + directories[i].ToString();
                            //string trnsfrpth = @"C:\Test\" + directories[i].ToString();
                            ftpClient.DownloadFile(path, trnsfrpth);
                    }
                }
            }
        }


        public utblMstConnection MstGetFTPConnection(int? ConnectionID)
        {
            utblMstConnection results = new utblMstConnection();

            var parConnectionID = new SqlParameter("@ConnectionID", ConnectionID);
            results = _db.Database.SqlQuery<utblMstConnection>("select * from utblMstConnections WHERE ConnectionID=@ConnectionID", parConnectionID).FirstOrDefault();
            return results;
        }
    }
}