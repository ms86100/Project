﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.DataAccess
{
    public class dalSQL
    {
      
        public string ExecuteSQL(string Query,int? DbConnectionID)
        {

            List<string> result;

            string CS = dalDatabaseConnection.ConnectionStrings(DbConnectionID);
            EFDDGeneric _db = new EFDDGeneric(CS);

            result = _db.Database.SqlQuery<List<string>>(Query).FirstOrDefault();
            return result == null ? "Success" : "Failure";
        }
    }
}