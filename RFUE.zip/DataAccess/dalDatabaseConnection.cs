﻿using FUE.Web.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace FUE.Web.DataAccess
{
    public class dalDatabaseConnection
    {

        public static string ConnectionStrings(int? Connection_k)
        {

            EFDBContext _db = new EFDBContext();
            C_DatabaseConnection Conn = new C_DatabaseConnection();
            string connectionString = string.Empty;
            try
            {
                var parConnection_k = new SqlParameter("@Connection_k", Connection_k);
                Conn = _db.Database.SqlQuery<C_DatabaseConnection>("SELECT * from C_DatabaseConnection Where Connection_k=@Connection_k", parConnection_k).FirstOrDefault();
                connectionString = "Data Source=" + Conn.DataSource + ";Initial Catalog=" + Conn.Catalog + "; user id = " + Conn.User_id + "; password=" + Conn.Password + "";
            }
            catch (Exception)
            {
                connectionString = ConfigurationManager.ConnectionStrings["EFDBContext"].ConnectionString;
                return connectionString;
            }
            return connectionString;
        }


        public static string GetConnectionData(int? Connection_k)
        {
            EFDBContext _db = new EFDBContext();
            C_DatabaseConnection Conn = new C_DatabaseConnection();
            string connectionString = string.Empty;
            try
            {
                var parConnection_k = new SqlParameter("@Connection_k", Connection_k);
                Conn = _db.Database.SqlQuery<C_DatabaseConnection>("SELECT * from C_DatabaseConnection Where Connection_k=@Connection_k", parConnection_k).FirstOrDefault();
                //connectionString = "Data Source=" + Conn.DataSource + ";Initial Catalog=" + Conn.Catalog + "; user id = " + Conn.User_id + "; password=" + Conn.Password + "";
            }
            catch (Exception)
            {
                return null;
            }
            return Conn.Catalog;
        }

    }
}