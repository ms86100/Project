﻿using FUE.Web.Models;
using FUE.Web.ViewModels;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace FUE.Web.DataAccess
{
    public class dalAPI
    {
        EFDBContext _db = new EFDBContext();

        public List<MstStepsExecutionView> GetStepsExecutionDetails(int? ImportID)
        {
            List<MstStepsExecutionView> _data = new List<MstStepsExecutionView>();
            var parImportID = new SqlParameter("@ImportID", ImportID ?? (object)DBNull.Value);
            _data = _db.Database.SqlQuery<MstStepsExecutionView>("udspGetJobDetails @ImportID", parImportID).ToList();
            return _data;
        }


        public List<utblMstStep> GetStepsDetails()
        {
            List<utblMstStep> _data = new List<utblMstStep>();

            _data = _db.Database.SqlQuery<utblMstStep>("SELECT * FROM utblMstSteps order by ImportID asc,  StepOrder asc").ToList();
            return _data;
        }
        public DataTable GetAPIData(string conString, string filePath = "~/Uploads/YourExcelFile.csv")
        {
            DataTable dt = new DataTable();
            //conString = string.Format(conString, "~/Uploads/");
            using (OleDbConnection connExcel = new OleDbConnection(conString))
            {
                using (OleDbCommand cmdExcel = new OleDbCommand())
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        cmdExcel.Connection = connExcel;
                        connExcel.Open();
                        DataTable dtExcelSchema;
                        dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        string sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                        connExcel.Close();
                        connExcel.Open();
                        cmdExcel.CommandText = "SELECT * From [YourExcelFile.csv]";
                        odaExcel.SelectCommand = cmdExcel;
                        odaExcel.Fill(dt);
                        connExcel.Close();
                    }
                }
            }
            return dt;
        }


        public string CreateTABLE(DataTable table, string SourceTable)
        {

            string tableName = SourceTable;

            string sqlsc, indexsc;
            string Indexname = tableName + "Index ";
            //table.PrimaryKey = new DataColumn[] { table.Columns[0] };
            //indexsc = "CREATE UNIQUE NONCLUSTERED INDEX " + Indexname + "ON " + "[dbo]." + tableName + "";
            //indexsc += "Ecode ASC, Months ASC, Years ASC )";


            sqlsc = "CREATE TABLE " + tableName + "(";
            for (int i = 0; i < table.Columns.Count; i++)
            {

                string ColumnName = !String.IsNullOrWhiteSpace(table.Columns[i].ColumnName) && table.Columns[i].ColumnName.Length >= 128 ? table.Columns[i].ColumnName.Substring(0, 100) : table.Columns[i].ColumnName;
                table.Columns[i].ColumnName = ColumnName;
                table.AcceptChanges();

                //string ColumnName = table.Columns[i].ColumnName.Length > 100 ? table.Columns[i].ColumnName.Substring(0, table.Columns[i].ColumnName.Length - 1) : table.Columns[i].ColumnName;



                sqlsc += "\n [" + ColumnName + "] ";
                string columnType = table.Columns[i].DataType.ToString();
                switch (columnType)
                {
                    case "System.Int32":
                        sqlsc += " int ";
                        break;
                    case "System.Int64":
                        sqlsc += " bigint ";
                        break;
                    case "System.Int16":
                        sqlsc += " smallint";
                        break;
                    case "System.Byte":
                        sqlsc += " tinyint";
                        break;
                    case "System.Decimal":
                        sqlsc += " decimal ";
                        break;
                    case "System.DateTime":
                        sqlsc += " datetime ";
                        break;
                    case "System.String":
                    default:
                        sqlsc += string.Format(" nvarchar({0}) ", table.Columns[i].MaxLength == -1 ? "250" : table.Columns[i].MaxLength.ToString());
                        break;
                }
                if (table.Columns[i].AutoIncrement)
                    sqlsc += " IDENTITY(" + table.Columns[i].AutoIncrementSeed.ToString() + "," + table.Columns[i].AutoIncrementStep.ToString() + ") ";
                if (!table.Columns[i].AllowDBNull)
                    sqlsc += " NOT NULL ";


                sqlsc += ",";

            }

            sqlsc = sqlsc.Substring(0, sqlsc.Length - 1) + "\n)";
            return sqlsc;
            //+= indexsc;

        }


        public string CreateMaptable(DataTable dt, string TableName, int? ConnectionID)
        {
            string Message = string.Empty;
            DataTable MapTable = new DataTable();
            string CS = dalDatabaseConnection.ConnectionStrings(ConnectionID);
            EFDDGeneric _db = new EFDDGeneric(CS);
            utblMstTableMapping result = new utblMstTableMapping();

            var parTableName = new SqlParameter("@TableName", TableName);



            var parTN = new SqlParameter("@TN", TableName);
            string Result = _db.Database.SqlQuery<string>("udspMstCheckIfTableExist @TN", parTN).FirstOrDefault();
            if (Result == "Found")
            {
                int ImportMapHeaderID = _db.Database.SqlQuery<int>("udspMstMapHeaderTableInsert @TableName", parTableName).FirstOrDefault();
                var parImportMapHeaderID = new SqlParameter("@ImportMapHeaderID", ImportMapHeaderID);
                result = _db.Database.SqlQuery<utblMstTableMapping>("select ID from utblMstTableMappings where ImportMapHeaderID=@ImportMapHeaderID", parImportMapHeaderID).FirstOrDefault();

                if (result == null)
                {
                    MapTable.Columns.Add("ID", typeof(int));
                    MapTable.Columns.Add("ImportMapHeaderID", typeof(int));
                    MapTable.Columns.Add("FromField", typeof(string));
                    MapTable.Columns.Add("ToField", typeof(string));
                    foreach (DataColumn DC in dt.Columns)
                    {   //DataRow row = MapTable.NewRow();
                        string ColumnName = !String.IsNullOrWhiteSpace(DC.ColumnName) && DC.ColumnName.Length >= 128 ? DC.ColumnName.Substring(0, 100) : DC.ColumnName;
                        MapTable.Rows.Add(null, ImportMapHeaderID, DC.ColumnName, DC.ColumnName);
                    }
                    Message = TVP(MapTable, "utblMstTableMappings", ConnectionID);
                }
            }

            return Message;
        }
        public string CreateTableProgramitacally(DataTable table, string SourceTable, int? ConnectionID)
        {
            SPErrorViewModel objStatus = new SPErrorViewModel();
            string CS = dalDatabaseConnection.ConnectionStrings(ConnectionID);
            EFDDGeneric _db = new EFDDGeneric(CS);

            string exceptionMsg = string.Empty;
            string SQL = CreateTABLE(table, SourceTable);
            try
            {
                string TableError = _db.Database.ExecuteSqlCommand(SQL).ToString();
                if (TableError == "-1")
                {
                    objStatus.ErrorMessage = "Successful";
                }
                else
                {
                    objStatus.ErrorMessage = "Duplicate data found and operation revoked";
                }

            }
            catch (Exception e)
            {

                objStatus.ErrorMessage = e.Message;

            }
            return objStatus.ErrorMessage;
        }
        public string TVP(DataTable dt, string SourceTable, int? ConnectionID)
        {
            string ErrorMessage = string.Empty;
            string tableName = SourceTable;
            string CS = dalDatabaseConnection.ConnectionStrings(ConnectionID);
            tableName = tableName.Replace(" ", string.Empty);
            try
            {

                //string _connectionString = ConfigurationManager.ConnectionStrings["EFDBContext"].ConnectionString;


                using (var sqlBulk = new SqlBulkCopy(CS))
                {
                    foreach (DataColumn col in dt.Columns)
                    {

                        sqlBulk.ColumnMappings.Add(col.ColumnName, col.ColumnName);

                    }
                    sqlBulk.DestinationTableName = tableName;
                    sqlBulk.BulkCopyTimeout = 8000;
                    sqlBulk.BatchSize = 10000;
                    sqlBulk.EnableStreaming = true;
                    sqlBulk.WriteToServer(dt);
                }
                ErrorMessage = null;

            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
            }

            return ErrorMessage;
        }


        public List<string> getColumns(string _connectionString, string SourceTable)
        {

            List<string> ret = new List<string>();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (SqlCommand com = conn.CreateCommand())
                {
                    com.CommandText = "select column_Name from information_schema.COLUMNS where table_name = @tab";
                    com.Parameters.AddWithValue("@tab", SourceTable);
                    SqlDataReader read = com.ExecuteReader();

                    while (read.Read())
                    {
                        ret.Add(Convert.ToString(read[0]));
                    }
                    conn.Close();
                }
            }
            return ret;

        }

        public void UpdateStatus(int ID, string Status)
        {
            utblMstSampleImport sample = _db.utblMstSampleImports.Single(abc => abc.Id == ID);
            sample.LastExecution = System.DateTime.Now;
            sample.Status = Status;
            _db.SaveChanges();
        }




        public List<MstMappingTable> GetMappingData(int? ImportMapHeaderID, int? ConnectionID)
        {
            List<MstMappingTable> _data = new List<MstMappingTable>();

            string CS = dalDatabaseConnection.ConnectionStrings(ConnectionID);
            EFDDGeneric _db = new EFDDGeneric(CS);

            var parMapHeaderID = new SqlParameter("@ImportMapHeaderID", ImportMapHeaderID);
            _data = _db.Database.SqlQuery<MstMappingTable>("select ID,FromField,ToField from utblMstImportMapHeaders MH inner Join utblMstTableMappings TM on MH.ImportMapHeaderID = TM.ImportMapHeaderID WHERE TM.ImportMapHeaderID = @ImportMapHeaderID", parMapHeaderID).ToList();

            //_data = _db.Database.SqlQuery<MstMappingTable>("SELECT * FROM " + tableName).ToList();
            return _data;
        }


        public DataTable MappingResolver(DataTable dt, List<MstMappingTable> Fields, string TableTo)
        {
            foreach (DataColumn DC in dt.Columns)
            {
                foreach (var item in Fields)
                {
                    string ColumnName = !String.IsNullOrWhiteSpace(DC.ColumnName) && DC.ColumnName.Length >= 128 ? DC.ColumnName.Substring(0, 100) : DC.ColumnName;

                    if (ColumnName == item.FromField)
                    {
                        dt.Columns[item.FromField].ColumnName = item.ToField;
                        dt.AcceptChanges();
                        //string FromColumn = TableTo + "." + item.FromField;
                        //string ToColumn = item.ToField;
                        //var parTableAndColumnName = new SqlParameter("@TableAndColumnName", FromColumn);
                        //var parNewColumnName = new SqlParameter("@NewColumnName", ToColumn);
                        //List<string> result = _db.Database.SqlQuery<List<string>>("udspMstColumnRename @TableAndColumnName,@NewColumnName", parTableAndColumnName, parNewColumnName).FirstOrDefault();
                    }
                }


            }
            return dt;
        }


        public string StaggingMove(string Source, string Destination, int? DbFromConnectionID, int? DbToConnectionID)
        {
            string SourceDb = dalDatabaseConnection.GetConnectionData(DbFromConnectionID);
            string DestinationDb = dalDatabaseConnection.GetConnectionData(DbToConnectionID);
            //string CS = dalDatabaseConnection.ConnectionStrings(DbFromConnectionID);
            //EFDDGeneric _db = new EFDDGeneric(CS);
            string sourceTable = SourceDb + ".dbo." + Source;
            string destinationTable = DestinationDb + ".dbo." + Destination;

            //string sourceTable = "FileUploadEngine.dbo." + Source;
            //string destinationTable = "Prod_FileImportEngine.dbo." + Destination;

            var parsourceTable = new SqlParameter("@FromTable", sourceTable);
            var pardestinationTable = new SqlParameter("@ToTable", destinationTable);

            List<string> result = _db.Database.SqlQuery<List<string>>("udspGetDataFromStagingToProduction @FromTable,@ToTable", parsourceTable, pardestinationTable).FirstOrDefault();

            return result == null ? null : "Error Insertion";
        }


        public DataTable ProductionMappingResolver(DataTable dt, List<MstMappingTable> Fields, string TableTo)
        {
            foreach (DataColumn DC in dt.Columns)
            {
                foreach (var item in Fields)
                {
                    if (DC.ColumnName == item.FromField)
                    {
                        dt.Columns[item.FromField].ColumnName = item.ToField;
                        string FromColumn = TableTo + "." + item.FromField;
                        string ToColumn = item.ToField;
                        dt.AcceptChanges();
                        var parTableAndColumnName = new SqlParameter("@TableAndColumnName", FromColumn);
                        var parNewColumnName = new SqlParameter("@NewColumnName", ToColumn);
                        _db.Database.SqlQuery<string>("udspMstColumnRename @TableAndColumnName,@NewColumnName", parTableAndColumnName, parNewColumnName).FirstOrDefault();

                    }
                }
            }
            return dt;
        }


        public int? TryParseNullable(string val)
        {
            int outValue;
            return int.TryParse(val, out outValue) ? (int?)outValue : null;
        }
    }
}