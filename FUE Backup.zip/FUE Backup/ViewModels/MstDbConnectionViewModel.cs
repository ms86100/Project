﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.ViewModels
{
    public class MstDbConnectionViewModel
    {
        public int connection_k { get; set; }
        public string catalog { get; set; }
    }
}