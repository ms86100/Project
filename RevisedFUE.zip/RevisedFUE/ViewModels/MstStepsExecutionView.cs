﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.ViewModels
{
    public class MstStepsExecutionView
    {
        public int ImportID
        { get; set; }
        public int StepOrder
        { get; set; }
        public string ImportName
        { get; set; }
        public string Action
        { get; set; }
        public string Parameter1
        { get; set; }
        public string Parameter2
        { get; set; }
        public string Parameter3
        { get; set; }

        public string Parameter4
        { get; set; }
        public string Parameter5
        { get; set; }
        public string Parameter6
        { get; set; }

        public string Parameter7
        { get; set; }
        public bool IsActive
        { get; set; }
        public DateTime EffectiveFrom
        { get; set; }
        public DateTime EffectiveTo
        { get; set; }


    }
}