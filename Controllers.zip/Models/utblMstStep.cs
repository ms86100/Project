﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.Models
{
    public class utblMstStep
    {
        public int StepsID { get; set; }
        public int ImportID { get; set; }
        public int StepOrder { get; set; }
        public string Action { get; set; }
        public string Parameter1 { get; set; }
        public string Parameter2 { get; set; }
        public string Parameter3 { get; set; }
        public string Parameter4 { get; set; }
        public string Parameter5 { get; set; }
        public string Parameter6 { get; set; }
     
    }
}