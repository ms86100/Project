﻿using Microsoft.SqlServer.Dts.Runtime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.SqlServer.Server;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using FUE.Web.Models;

namespace FUE.Web.DataAccess
{
    public class dalSSIS
    {
        public void SSIS()
        {
            try
            {
                Application app = new Application();

                Package package = null;
                package = app.LoadPackage(@"C:\Test\SSISPACAKAGE.dtsx", null);

                //Excute Package 
                Microsoft.SqlServer.Dts.Runtime.DTSExecResult results = package.Execute();

                if (results == Microsoft.SqlServer.Dts.Runtime.DTSExecResult.Failure)
                {
                    foreach (Microsoft.SqlServer.Dts.Runtime.DtsError local_DtsError in package.Errors)
                    {

                        Console.WriteLine("Package Execution results: {0}", local_DtsError.Description.ToString());
                        Console.WriteLine();
                    }
                }

            }
            catch (DtsException ex)
            {
                //Exception = ex.Message;
            }

        }

        public string RunLoad()
        {
            string result = string.Empty;
            int rows = 0;
            string PackagePath = @"C:\Test\SSISPACAKAGE.dtsx";
            string SPCallSSIS = "[sp_ExecPackage]"; // Stored Procedure Name

           
            //SqlParameter paramEmpCode = new SqlParameter("@EmpCode", "2");
            //paramEmpCode.SqlDbType = System.Data.SqlDbType.VarChar;
            //SqlParameter paramEmpName = new SqlParameter("@EmpName", "SANDEEP");
            //paramEmpName.SqlDbType = System.Data.SqlDbType.VarChar;
            SqlParameter paramPackagePath = new SqlParameter("@PackagePath", PackagePath);
            paramPackagePath.SqlDbType = System.Data.SqlDbType.VarChar;

            SqlParameter[] paramList = { paramPackagePath };
            rows = executeCommandQuery(SPCallSSIS, CommandType.StoredProcedure, paramList); // Executing Stored Procedure
            if (rows > 0)
            {
                result = "Success";
            }
            else
            {
                result = "Error";
            }
            return result;
        }


        public int executeCommandQuery(String sQuery, CommandType commandType, SqlParameter[] Param)
        {
            EFDBContext _db = new EFDBContext();
            C_DatabaseConnection Conn = new C_DatabaseConnection();
            int rowEffected = 0;
            string connectionString = string.Empty;
            //Conn = _db.Database.SqlQuery<utblMstDatabaseConnection>("SELECT * from utblMstDatabaseConnections Where TYPE='Production'").FirstOrDefault();
            SqlConnection con=new SqlConnection();
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["EFDBContext"].ConnectionString);
                //connectionString = ConfigurationManager.ConnectionStrings["EFDBContext"].ConnectionString; //From Web.config
                //connectionString = "Data Source=" + Conn.DataSource + ";Initial Catalog=" + Conn.Catalog + "; user id = " + Conn.User_id + "; password=" + Conn.Password + "";
                //string connectionString = "Data Source=DEL1-LT2VWCRV2\\SQLEXPRESS;Initial Catalog=Prod_FileImportEngine; user id = sa; password=Welcome123";
                 //con = new SqlConnection(connectionString);
                con.Open();

                SqlCommand command = new SqlCommand(sQuery, con);
                command.CommandType = commandType;
                command.Parameters.AddRange(Param);
                command.CommandTimeout = 0;
                rowEffected = command.ExecuteNonQuery();
                con.Close();
            }

            catch (Exception ex)
            {
                rowEffected = -9;
                con.Close();
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return rowEffected;
        }


        }
}