﻿using FUE.Web.ViewModels;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace FUE.Web.DataAccess
{
    public class dalValidation
    {
        EFDBContext _db = new EFDBContext();
        public string ValidationStepOne(int? project_k)
        {
            List<string> result = new List<string>();
            var parProjectID = new SqlParameter("@project_k", project_k);
            result = _db.Database.SqlQuery<List<string>>("udspGetValidationData @project_k", parProjectID).FirstOrDefault();
            return result == null ? "" : result[0];
        }


        public string ValidationStepTwo(int? project_k)
        {
            
            SPErrorViewModel result = new SPErrorViewModel();
            var parProjectID = new SqlParameter("@project_k", project_k);
            result = _db.Database.SqlQuery<SPErrorViewModel>("udspGetValidationResult @project_k", parProjectID).FirstOrDefault();
            return result.ErrorMessage;
        }
    }
}