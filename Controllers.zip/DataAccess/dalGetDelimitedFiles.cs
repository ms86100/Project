﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
//using Microsoft.Office.Interop.Excel;

namespace FUE.Web.DataAccess
{
    public class dalGetDelimitedFiles
    {

        public DataTable GetFile(string Source, string Destination, string Delimiter, string TempPathToDumpFileName, int? SkipRowHeader)
        {
            DataTable dt = null;
            try
            {

                if (Source.Contains("http"))
                {

                    WebClient clients = new WebClient();
                    TempPathToDumpFileName = TempPathToDumpFileName + "Filehttp_http" + ".csv";
                    clients.DownloadFile(Source, TempPathToDumpFileName);
                    //string conString = ConfigurationManager.ConnectionStrings["Excel07ConString"].ConnectionString;
                    var FilePath = string.Format("{0}{1}", AppDomain.CurrentDomain.BaseDirectory, "Uploads\\");
                    string fileName = Path.GetFileName(TempPathToDumpFileName);
                    string connectionString = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0; Data Source={0}; Extended Properties=""text;HDR=YES;FMT=Delimited""", FilePath);
                    dt = GetAPIData(connectionString, FilePath, fileName);
                    return dt;

                    //insert into destination table


                }
                else
                {

                    bool IsValid = IsValidPath(Source);
                    var FilePath = string.Format("{0}{1}", AppDomain.CurrentDomain.BaseDirectory, "Uploads\\");

                    string Extension = Path.GetExtension(Source);
                    if (Extension.Equals(".txt"))
                    {
                        dalTexttoExcel txtToExcel = new dalTexttoExcel();
                        TempPathToDumpFileName = TempPathToDumpFileName + "File_Txt" + ".csv";
                        bool IsSaved = txtToExcel.ConvertToXlsx(Source, TempPathToDumpFileName);

                        if (IsSaved)
                        {
                            string fileName = Path.GetFileName(TempPathToDumpFileName);
                            string connectionString = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0; Data Source={0}; Extended Properties=""text;HDR=YES;FMT=Delimited""", FilePath);
                            dt = GetAPIData(connectionString, FilePath, fileName);
                            return dt;
                        }
                    }

                    if (Extension.Equals(".xlsx") || Extension.Equals(".csv"))
                    {
                        if (SkipRowHeader != null)
                        {
                            string conn = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Source + ";Extended Properties='Excel 12.0;HDR=NO;IMEX=1;';";
                            dt = ConvertExcelToDataTable(conn, Source);
                        }
                        else
                        {
                            string conn = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Source + ";Extended Properties='Excel 12.0;HDR=YES;IMEX=1;';";
                            dt = ConvertExcelToDataTable(conn, Source);
                        }

                    }

                }


            }

            catch (Exception ex)
            {
                return null;
            }
            return dt;
        }

        public DataTable GetAPIData(string conString, string FilePath, string FileName)
        {
            DataTable dt = new DataTable();

            //conString = string.Format(conString, "~/Uploads/");
            using (OleDbConnection connExcel = new OleDbConnection(conString))
            {
                using (OleDbCommand cmdExcel = new OleDbCommand())
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        cmdExcel.Connection = connExcel;
                        connExcel.Open();
                        DataTable dtExcelSchema;
                        dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        string sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                        connExcel.Close();
                        connExcel.Open();
                        cmdExcel.CommandText = "SELECT * From " + FileName;
                        odaExcel.SelectCommand = cmdExcel;
                        odaExcel.Fill(dt);
                        connExcel.Close();
                    }
                }
            }
            return dt;
        }


        public static DataTable ConvertExcelToDataTable(string Connection, string FileName)
        {
            DataTable dtResult = null;
            int totalSheet = 0; //No of sheets on excel file  
            using (OleDbConnection objConn = new OleDbConnection(Connection))
            {
                objConn.Open();
                OleDbCommand cmd = new OleDbCommand();
                OleDbDataAdapter oleda = new OleDbDataAdapter();
                DataSet ds = new DataSet();
                DataTable dt = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                string sheetName = string.Empty;
                if (dt != null)
                {
                    var tempDataTable = (from dataRow in dt.AsEnumerable()
                                         where !dataRow["TABLE_NAME"].ToString().Contains("FilterDatabase")
                                         select dataRow).CopyToDataTable();
                    dt = tempDataTable;
                    totalSheet = dt.Rows.Count;
                    sheetName = dt.Rows[0]["TABLE_NAME"].ToString();
                }
                cmd.Connection = objConn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT * FROM [" + sheetName + "]";
                oleda = new OleDbDataAdapter(cmd);
                oleda.Fill(ds, "excelData");
                dtResult = ds.Tables["excelData"];
                objConn.Close();
                return dtResult; //Returning Dattable  
            }
        }


        private bool IsValidPath(string path, bool allowRelativePaths = false)
        {
            bool isValid = true;

            try
            {
                string fullPath = Path.GetFullPath(path);

                if (allowRelativePaths)
                {
                    isValid = Path.IsPathRooted(path);
                }
                else
                {
                    string root = Path.GetPathRoot(path);
                    isValid = string.IsNullOrEmpty(root.Trim(new char[] { '\\', '/' })) == false;
                }
            }
            catch (Exception ex)
            {
                isValid = false;
            }

            return isValid;
        }


        public DataTable TXToExcel()
        {
            DataTable dt = null;
            string line;
            using (StreamReader reader = new StreamReader(@"yourFilePath.txt"))
            {
                while ((line = reader.ReadLine()) != null)
                {
                    using (StreamWriter writer = new StreamWriter(@"yourFilePath.csv", true))
                    {
                        writer.WriteLine(line.Replace(",", ";"));
                    }
                }
            }
            return dt;
        }


        public DataTable RemoveEscapeCharacter(DataTable dt, string ECharacter)
        {
            for (int i = 0; i <= dt.Rows.Count - 1; i++)
            {
                dt.Rows[i][1] = dt.Rows[i][1].ToString().Replace(ECharacter, " ");
            }
            dt.AcceptChanges();
            return dt;
        }

        public DataTable EscapeCharacter(DataTable dt, string ECharacter)
        {
            foreach (DataRow row in dt.Rows)
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    if (dt.Columns[i].DataType == typeof(string))
                        //row[i] = ReplaceHexadecimalSymbols((string)row[i]);
                        row[i] = (string)row[i].ToString().Replace(ECharacter, " ");
                }
            }
            dt.AcceptChanges();
            return dt;

        }
        static string ReplaceHexadecimalSymbols(string txt)
        {
            string r = "[\x00-\x08\x0B\x0C\x0E-\x1F\x26]";
            return Regex.Replace(txt, r, "", RegexOptions.Compiled);
        }


    }

}
