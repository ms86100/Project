﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.Models
{
    public class C_ImportSteps
    {
        public int Step_K { get; set; }
        public int Import_k { get; set; }
        public int StepOrder { get; set; }
        public string Action { get; set; }
        public string Parameter1 { get; set; }
        public string Parameter2 { get; set; }
        public string Parameter3 { get; set; }
        public string Parameter4 { get; set; }
        public string Parameter5 { get; set; }
        public string Parameter6 { get; set; }
     
    }
}