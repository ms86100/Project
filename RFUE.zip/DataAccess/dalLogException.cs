﻿using FUE.Web.ViewModels;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace FUE.Web.DataAccess
{
    public class dalLogException
    {
        EFDBContext _db = new EFDBContext();
        SPErrorViewModel ErrorResult = new SPErrorViewModel();
        public int LogStart(string logrunname)
        {
            int logh_k = 0;
            var parProcess = new SqlParameter("@process", "FIE");
            var parLogrunname = new SqlParameter("@logrunname", logrunname);
            var parStart = new SqlParameter("@start", DBNull.Value);
            var parLogend = new SqlParameter("@logend", DBNull.Value);
            var parLogstatus = new SqlParameter("@logstatus", "Started");
            var parLogresult = new SqlParameter("@logresult", "inprogress");
            logh_k = _db.Database.SqlQuery<int>("c_logStart @process,@logrunname,@start,@logend,@logstatus,@logresult", parProcess, parLogrunname, parStart, parLogend, parLogstatus, parLogresult).FirstOrDefault();
            return logh_k;
        }


        public int LogAdd(int logh_k, string CountTable, string logstep, string logresult, string lognote)
        {
            int result = 0;
            var parlogh_k = new SqlParameter("@logh_k", (long)logh_k);
            var parResCount = new SqlParameter("@resCount", DBNull.Value);
            var parCountTable = new SqlParameter("@CountTable", CountTable??(object)DBNull.Value);
            var parLogstep = new SqlParameter("@logstep", logstep);
            var parLogresult = new SqlParameter("@logresult", logresult);
            var parLognote = new SqlParameter("@lognote", lognote??(object)DBNull.Value);
            result = _db.Database.SqlQuery<int>("c_logAdd @logh_k,@resCount,@CountTable,@logstep,@logresult,@lognote", parlogh_k, parResCount, parCountTable, parLogstep, parLogresult, parLognote).FirstOrDefault();
            return result;
        }


        public string LogEND(long logh_k, string logresult)
        {

            var parlogh_k = new SqlParameter("@logh_k", (long)logh_k);
            var parLogresult = new SqlParameter("@logresult", logresult);
            ErrorResult = _db.Database.SqlQuery<SPErrorViewModel>("c_logEnd @logh_k,@logresult", parlogh_k, parLogresult).FirstOrDefault();
            return ErrorResult.ErrorMessage; ;
        }
    }
}