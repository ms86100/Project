﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FUE.Web.Models
{
    public class C_ImportStepMappingMove
    {
        [Key]
        public int step_k { get; set; }

        //[Display(Name = "Import Name")]
        //[Required(ErrorMessage = "Please select Import Name")]
        public int import_k { get; set; }

        //[Display(Name = "Action")]
        //[Required(ErrorMessage = "Please select Action")]
        public string action { get; set; }

        [Display(Name = "Step Order")]
        public string stepOrder { get; set; }

        [Display(Name = "From Table")]
        [Required(ErrorMessage = "parameter1 is required")]
        //[Url(ErrorMessage = "Please enter a valid url")]
        public string parameter1 { get; set; }
        [Required]
        [Display(Name = "To Table")]
        //[Required(ErrorMessage = "parameter2 is required")]
        public string parameter2 { get; set; }

        [Display(Name = "Map Table")]
        //[Required(ErrorMessage = "Please select parameter3")]
        public string parameter3 { get; set; }
        [Required]
        [Display(Name = "From Connection")]
        //[Required(ErrorMessage = "Please select parameter4")]
        public string parameter4 { get; set; }
        [Required]
        [Display(Name = "To Connection")]
        public string parameter5 { get; set; }

        [Display(Name = "parameter6")]
        public string parameter6 { get; set; }

        [Display(Name = "parameter7")]
        public string parameter7 { get; set; }
    }

}