﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace FUE.Web.DataAccess
{
    public class EFDDGeneric:DbContext
    {
        public EFDDGeneric(string connString)
        {
            this.Database.Connection.ConnectionString = connString;
        }
    }
}