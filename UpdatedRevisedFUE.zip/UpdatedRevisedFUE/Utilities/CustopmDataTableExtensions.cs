﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace FUE.Web.Utilities
{
    public static class CustopmDataTableExtensions
    {
        public static string WriteToCsvFile(this DataTable dt, string filePath)
        {
            StringBuilder sb = new StringBuilder();

            var columnNames = dt.Columns.Cast<DataColumn>().Select(column => "\"" + column.ColumnName.Replace("\"", "\"\"") + "\"").ToArray();
            sb.AppendLine(string.Join(",", columnNames));

            foreach (DataRow row in dt.Rows)
            {
                var fields = row.ItemArray.Select(field => "\"" + field.ToString().Replace("\"", "\"\"") + "\"").ToArray();
                sb.AppendLine(string.Join(",", fields));
            }
            filePath = filePath + "SomeFile" + ".csv";
            File.WriteAllText(filePath, sb.ToString(), Encoding.Default);
            return filePath;
        }
    }
}