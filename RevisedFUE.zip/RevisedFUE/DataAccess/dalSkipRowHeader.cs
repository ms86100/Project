﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace FUE.Web.DataAccess
{
    public class dalSkipRowHeader
    {
        public static DataTable ETL(DataTable dtFromExternal, DataTable dtFromDatabase, int SkipRowHeader)
        {

            try
            {
                if (dtFromDatabase.Columns.Count == dtFromExternal.Columns.Count)
                {
                    if (SkipRowHeader > 0)
                    {
                        while (dtFromExternal.Columns.Count > dtFromDatabase.Columns.Count)
                        {
                            dtFromExternal.Columns.RemoveAt(dtFromDatabase.Columns.Count);
                        }

                        for (int i = 0; i <= dtFromDatabase.Columns.Count - 1; i++)
                        {
                            dtFromExternal.Columns[i].ColumnName = dtFromDatabase.Columns[i].ColumnName;
                        }


                    }
                    if (SkipRowHeader > 0)
                    {
                        for (int i = SkipRowHeader - 1; i >= 0; i--)
                        {
                            DataRow row = dtFromExternal.Rows[0];
                            dtFromExternal.Rows.Remove(row);

                        }
                    }
                    dtFromExternal.AcceptChanges();

                    return dtFromExternal;
                }
            }
            catch (Exception e)
            {
                return null;
            }
            return null;
        }




        public static DataTable RemoveRow(DataTable dtFromExternal, int SkipRowHeader)
        {
            try
            {
                if (SkipRowHeader > 0)
                {
                    for (int i = SkipRowHeader - 1; i >= 0; i--)
                    {
                        DataRow row = dtFromExternal.Rows[0];
                        dtFromExternal.Rows.Remove(row);

                    }
                }
                dtFromExternal.AcceptChanges();
                return dtFromExternal;
            }
            catch (Exception e)
            {
                return null;
            }
          
        }

        public static DataTable GetTableSchema(string tableName, int? ConnectionID)
        {
            //string _connectionStringStagging = ConfigurationManager.ConnectionStrings["EFDBContext"].ConnectionString;
            string CS = dalDatabaseConnection.ConnectionStrings(ConnectionID);

            string query = string.Format("SELECT TOP 0 * FROM {0}", tableName);
            using (SqlConnection localSqlConn = new SqlConnection(CS))
            {
                DataSet ds = new DataSet();

                SqlCommand sqlCmd = new SqlCommand(query, localSqlConn);
                SqlDataAdapter sda = new SqlDataAdapter(sqlCmd);

                sda.FillSchema(ds, SchemaType.Source, tableName);
                sda.Fill(ds, tableName);

                sda.Dispose();

                DataTable dt = ds.Tables[0];
                return dt;
            }
        }

    }
}