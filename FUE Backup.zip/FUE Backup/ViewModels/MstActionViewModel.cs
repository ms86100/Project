﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.ViewModels
{
    public class MstActionViewModel
    {
        public int action_k { get; set; }
        public string action { get; set; }
    }
}