﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
namespace FUE.Web.DataAccess
{
    public class dalTexttoExcel
    {
        public bool ConvertToXlsx(string sourcefile, string destfile)
        {
            bool IsSaved = false;
            try
            {

                
                List<string> lstColumnNames = new List<string>();
                List<List<string>> lstRowData = new List<List<string>>();

                System.IO.StreamReader file =
                 new System.IO.StreamReader(sourcefile);
                string line = "";
                int counter = 0;
                while ((line = file.ReadLine()) != null)
                {
                    if (counter == 0)
                    {
                        lstColumnNames.AddRange(line.Split(' '));
                    }
                    else
                    {
                        List<string> tempRowData = new List<string>();
                        tempRowData.AddRange(line.Split(' '));
                        lstRowData.Add(tempRowData);
                    }
                    counter++;
                }
                System.IO.TextWriter tw = new System.IO.StreamWriter(destfile);

                if (lstColumnNames.Count != 0)
                {
                    string temp = "";
                    foreach (string str in lstColumnNames)
                    {
                        //if (temp != "")
                        //{
                        //    temp += ";";
                        //}
                        temp += str;
                    }
                    tw.WriteLine(temp);


                    foreach (List<string> lstRow in lstRowData)
                    {
                        temp = "";

                        foreach (string str in lstRow)
                        {
                            //if (temp != "")
                            //{
                            //    temp += ";";
                            //}
                            temp += str;
                        }
                        tw.WriteLine(temp);
                    }
                    tw.Close();
                }

                IsSaved = true;


            }
            catch (Exception ex)
            {
                IsSaved = false;
            }

            return IsSaved;



        }
    }
}