﻿using FUE.Web.Models;
using FUE.Web.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.ViewModels
{
    public class MstFileUploadEngineManageModel
    {
        public List<MstDelimeter> MstDelimeterDDL { get; set; }
        public string PartialViewName { get; set; }
        public IEnumerable<MstImportStepViewModel> MstImportStepList { get; set; }
        public IEnumerable<MstDbConnectionViewModel> MstDbConnectionDDL { get; set; }
        public IEnumerable<MstImportMapHeaderViewModel> MstImportMapHeaderDDL { get; set; }
        public IEnumerable<MstActionViewModel> MstActionDDL { get; set; }
        public IEnumerable<MstImportJobViewModel> MstImportJobDDL { get; set; }

        public C_ImportStepFTP C_ImportStepFTPs { get; set; }
        public C_ImportStepImportdelimitedfile C_ImportStepImportdelimitedfiles { get; set; }
        public C_ImportStepMappingMove C_ImportStepMappingMoves { get; set; }
        public C_ImportStepImportAPI C_ImportStepImportAPIs { get; set; }

        public C_ImportStep C_ImportSteps { get; set; }
        public C_Action C_Actions { get; set; }
        public C_ImportJob C_ImportJobs { get; set; }
        public PagingInfo PagingInfo { get; set; }


    }

    public class MstDelimeter
    {
        public int delimeterId { get; set; }
        public string delimeter { get; set; }
    }
}