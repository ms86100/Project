﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FUE.Web.Models
{
    public class C_Action
    {
        [Key]
        public int actions_k { get; set; }
        [Display(Name = "Action")]
        [Required(ErrorMessage = "Please select Action")]
        public string action { get; set; }
    }
}