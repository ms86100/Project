﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FUE.Web.Models
{
    public class C_ImportStepImportdelimitedfile
    {
        public int step_k { get; set; }

        //[Display(Name = "Import Name")]
        //[Required(ErrorMessage = "Please select Import Name")]
        public int import_k { get; set; }

        //[Display(Name = "Action")]
        //[Required(ErrorMessage = "Please select Action")]
        public string action { get; set; }

        [Display(Name = "Step Order")]
        public string stepOrder { get; set; }

        [Required]
        [Display(Name = "Url / FilePath")]
        public string parameter1 { get; set; }
        [Required]
        [Display(Name = "Destination Table")]
        //[Required(ErrorMessage = "parameter2 is required")]
        public string parameter2 { get; set; }

        [Display(Name = "MapTable")]
        //[Required(ErrorMessage = "Please select parameter3")]
        public string parameter3 { get; set; }
        [Required]
        [Display(Name = "Connection")]
        //[Required(ErrorMessage = "Please select parameter4")]
        public string parameter4 { get; set; }

        [Display(Name = "Delimiter")]
        public string parameter5 { get; set; }

        [Display(Name = "Skip Header Row")]
        public string parameter6 { get; set; }

        [Display(Name = "Escape Character")]
        public string parameter7 { get; set; }
    }

}