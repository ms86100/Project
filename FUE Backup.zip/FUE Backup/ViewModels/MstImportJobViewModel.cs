﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.ViewModels
{
    public class MstImportJobViewModel
    {
        public int import_k { get; set; }
        public string importName { get; set; }
    }
}