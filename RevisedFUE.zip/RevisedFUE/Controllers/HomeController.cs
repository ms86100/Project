﻿using FUE.Web.DataAccess;
using FUE.Web.ViewModels;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using FUE.Web.Models;
using ChoETL;
using Microsoft.VisualBasic.FileIO;

namespace FUE.Web.Controllers
{
    public class HomeController : Controller
    {
        dalAPI dal = new dalAPI();
        MstAPIManageModel Model = new MstAPIManageModel();
        public ActionResult Index(int? ImportID)
        {
            Model.MstSteps = dal.GetStepsExecutionDetails(ImportID);
            Model.ExecptionError = new ExceptionErrorModel();
            dalLogException dalException = new dalLogException();

            DataTable FinalTable = new DataTable();
            string ErrMsg = string.Empty;
            int logh_k = 0;
            int Import_id = 0;

            foreach (var item in Model.MstSteps)
            {

                if (item.ImportID != Import_id)
                {
                    logh_k = dalException.LogStart(item.ImportName + "-" + "id" + "{" + item.ImportID + "}");
                    Import_id = item.ImportID;
                }


                try
                {
                    switch (item.Action)
                    {
                        case "ImportAPI":

                            if (Model.ExecptionError.Id == item.ImportID && Model.ExecptionError.ReferenceError != null)
                            {
                                break;
                            }
                            FinalTable = new DataTable();
                            try
                            {
                                //logh_k = dalException.LogStart(item.Action + item.ImportName);
                                using (var webClient = new System.Net.WebClient())
                                {
                                    DataTable dt = new DataTable();
                                    var json = webClient.DownloadString(item.Parameter1.Trim());
                                    JArray jsonArray = JArray.Parse(json);
                                    for (int i = 0; i < jsonArray.Count; i++)
                                    {
                                        JObject data = JObject.Parse(jsonArray[i].ToString());
                                        using (var r = new ChoJSONReader(data))
                                        {
                                            dt = r.AsDataTable();
                                            FinalTable.Merge(dt);
                                            dt.AcceptChanges();
                                            FinalTable.AcceptChanges();
                                        }
                                    }

                                    item.Parameter2 = item.Parameter2.Substring(item.Parameter2.LastIndexOf(':') + 1);
                                    item.Parameter4 = item.Parameter4 != null ? item.Parameter4.Substring(item.Parameter4.LastIndexOf(':') + 1) : null;

                                    if (item.Parameter3 != null)
                                    {
                                        item.Parameter3 = item.Parameter3.Substring(item.Parameter3.LastIndexOf(':') + 1);
                                        int? MapHeaderID = TryParseNullable(item.Parameter3);
                                        Model.MstMapping = dal.GetMappingData(MapHeaderID, null);
                                        //Model.MstMapping = dal.GetMappingData(MapHeaderID, TryParseNullable(item.Parameter4));
                                        FinalTable = dal.MappingResolver(FinalTable, Model.MstMapping, item.Parameter2);
                                    }
                                    ErrMsg = dal.CreateTableProgramitacally(FinalTable, item.Parameter2, TryParseNullable(item.Parameter4));
                                    //ErrMsg = dal.CreateTableProgramitacally(FinalTable, item.Parameter2);
                                    string Msg = dal.CreateMaptable(FinalTable, item.Parameter2, null);
                                    //string Msg = dal.CreateMaptable(FinalTable, item.Parameter2, TryParseNullable(item.Parameter4));

                                    //string Msg = dal.CreateMaptable(FinalTable, item.Parameter2);
                                    if (!string.IsNullOrEmpty(ErrMsg))//Table Already Exist or created successfully Simply Add data 
                                    {
                                        //string TVP = dal.TVP(FinalTable, item.Parameter2, null);
                                        string TVP = dal.TVP(FinalTable, item.Parameter2, TryParseNullable(item.Parameter4));
                                    }

                                }
                            }
                            catch (Exception e)
                            {
                                Model.ExecptionError.Id = item.ImportID;
                                Model.ExecptionError.ReferenceError = "Step Order" + item.StepOrder + "-" + item.Action;
                                Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.StackTrace;
                                dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                                dalException.LogEND(logh_k, "failure");
                                break;
                            }
                            dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "success", null);
                            dalException.LogEND(logh_k, "success");
                            break;
                        case "MappingMove":
                            //logh_k = dalException.LogStart(item.Action + item.ImportName);
                            if (Model.ExecptionError.Id == item.ImportID && Model.ExecptionError.ReferenceError != null)
                            {
                                //dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", "Gracefully failed due to error in  " + Model.ExecptionError.ReferenceError);
                                //dalException.LogEND(logh_k, "failure");

                                break;
                            }

                            else
                            {
                                try
                                {
                                    dalMappingMove dalMappingMove = new dalMappingMove();
                                    string TableFrom = item.Parameter1.Substring(item.Parameter1.LastIndexOf(':') + 1);
                                    string TableTo = item.Parameter2.Substring(item.Parameter2.LastIndexOf(':') + 1);
                                    item.Parameter3 = item.Parameter3 != null ? item.Parameter3.Substring(item.Parameter3.LastIndexOf(':') + 1) : null;
                                    item.Parameter4 = item.Parameter4 != null ? item.Parameter4.Substring(item.Parameter4.LastIndexOf(':') + 1) : null;
                                    item.Parameter5 = item.Parameter5 != null ? item.Parameter5.Substring(item.Parameter5.LastIndexOf(':') + 1) : null;
                                    bool results = dalMappingMove.CheckIfTableExist(TableTo, TryParseNullable(item.Parameter5));
                                    if (results)
                                    {
                                        if (item.Parameter3 != null)
                                        {
                                            DataTable ProductionSchema = dalMappingMove.GetTableSchemaProduction(TableTo, TryParseNullable(item.Parameter5));
                                            //DataTable ProductionSchema = dalMappingMove.GetTableSchemaProduction(TableFrom,TryParseNullable(item.Parameter4));
                                            //Model.MstMapping = dal.GetMappingData(TryParseNullable(item.Parameter3), TryParseNullable(item.Parameter4));
                                            Model.MstMapping = dal.GetMappingData(TryParseNullable(item.Parameter3), null);
                                            dalMappingMove.ProductionMappingResolver(ProductionSchema, Model.MstMapping, TableTo, TryParseNullable(item.Parameter5));
                                            string result = dal.StaggingMove(TableFrom, TableTo, TryParseNullable(item.Parameter4), TryParseNullable(item.Parameter5));
                                        }

                                        else
                                        {
                                            string result = dal.StaggingMove(TableFrom, TableTo, TryParseNullable(item.Parameter4), TryParseNullable(item.Parameter5));
                                        }
                                    }

                                    else
                                    {
                                        DataTable StaggingSchema = dalMappingMove.GetTableSchemaStagging(TableFrom, TryParseNullable(item.Parameter4));
                                        ErrMsg = dalMappingMove.CreateTableProgramitacally(StaggingSchema, TableTo, TryParseNullable(item.Parameter5));

                                        //newly added
                                        string Msg = dal.CreateMaptable(StaggingSchema, TableTo, null);

                                        //string Msg = dal.CreateMaptable(StaggingSchema, TableTo, TryParseNullable(item.Parameter5));


                                        if (!string.IsNullOrEmpty(ErrMsg))//Table Already Exist or created successfully Simply Add data 
                                        {
                                            string result = dal.StaggingMove(TableFrom, TableTo, TryParseNullable(item.Parameter4), TryParseNullable(item.Parameter5));
                                        }
                                    }
                                }
                                catch (Exception e)
                                {
                                    Model.ExecptionError.Id = item.ImportID;
                                    Model.ExecptionError.ReferenceError = "Step Order" + item.StepOrder + "-" + item.Action;
                                    Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.StackTrace;
                                    dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                                    dalException.LogEND(logh_k, "failure");
                                    break;
                                }
                                dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "success", null);
                                dalException.LogEND(logh_k, "success");
                            }


                            break;
                        case "FTP":
                            dalGetFTP dalFTP = new dalGetFTP();
                            if (Model.ExecptionError.Id == item.ImportID && Model.ExecptionError.ReferenceError != null)
                            {
                                break;
                            }
                            else
                            {

                                Model.utblMstConnections = new utblMstConnection();
                                try
                                {


                                    item.Parameter1 = item.Parameter1 != null ? item.Parameter1.Substring(item.Parameter1.LastIndexOf(':') + 1) : null;
                                    item.Parameter3 = item.Parameter3.Substring(item.Parameter3.LastIndexOf(':') + 1);
                                    Model.utblMstConnections = dalFTP.MstGetFTPConnection(TryParseNullable(item.Parameter1));
                                    dalFTP.GETFTPFILE(Model.utblMstConnections.URL, Model.utblMstConnections.UserName, Model.utblMstConnections.Password, item.Parameter3);
                                }
                                catch (Exception e)
                                {
                                    Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.StackTrace;
                                    dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                                    dalException.LogEND(logh_k, "failure");
                                    break;
                                }
                            }
                            break;
                        case "Importdelimitedfile":
                            dalGetDelimitedFiles dalDelimited = new dalGetDelimitedFiles();

                            if (Model.ExecptionError.Id == item.ImportID && Model.ExecptionError.ReferenceError != null)
                            {

                                break;
                            }
                            else
                            {

                                try
                                {
                                    //logh_k = dalException.LogStart(item.Action + item.ImportName);

                                    if (!item.Parameter1.Contains("http"))
                                    {
                                        item.Parameter1 = item.Parameter1 != null ? item.Parameter1.Substring(item.Parameter1.LastIndexOf(':') + 1) : null;
                                    }
                                    item.Parameter2 = item.Parameter2 != null ? item.Parameter2.Substring(item.Parameter2.LastIndexOf(':') + 1) : null;
                                    item.Parameter4 = item.Parameter4 != null ? item.Parameter4.Substring(item.Parameter4.LastIndexOf(':') + 1) : null;
                                    item.Parameter5 = item.Parameter5 != null ? item.Parameter5.Substring(item.Parameter5.LastIndexOf(':') + 1) : null;
                                    item.Parameter6 = item.Parameter6 != null ? item.Parameter6.Substring(item.Parameter6.LastIndexOf(':') + 1) : null;
                                    item.Parameter7 = item.Parameter7 != null ? item.Parameter7.Substring(item.Parameter7.LastIndexOf(':') + 1) : null;
                                    string TempFIlePathToDump = Server.MapPath("~/Uploads/");
                                    //no need of DbconnectionID
                                    FinalTable = dalDelimited.GetFile(item.Parameter1, item.Parameter2, "", TempFIlePathToDump, TryParseNullable(item.Parameter6));
                                    if (!string.IsNullOrEmpty(item.Parameter5))
                                    {
                                        FinalTable = dalDelimited.EscapeCharacter(FinalTable, item.Parameter5);
                                    }
                                    if (item.Parameter4 != null)
                                    {   //Look into the Map Table
                                        int? MapHeaderID = TryParseNullable(item.Parameter4);
                                        Model.MstMapping = dal.GetMappingData(MapHeaderID, null);
                                        //no need of DbconnectionID
                                        FinalTable = dal.MappingResolver(FinalTable, Model.MstMapping, item.Parameter2);
                                    }


                                    ErrMsg = dal.CreateTableProgramitacally(FinalTable, item.Parameter2, TryParseNullable(item.Parameter7));
                                    string Msg = dal.CreateMaptable(FinalTable, item.Parameter2, null);
                                    if (!string.IsNullOrEmpty(ErrMsg))//Table Already Exist or created successfully Simply Add data 
                                    {
                                        string TVP = dal.TVP(FinalTable, item.Parameter2, TryParseNullable(item.Parameter7));
                                    }


                                    //if (TryParseNullable(item.Parameter6) != null && TryParseNullable(item.Parameter6) > 0)
                                    //{
                                    //    DataTable StaggingSchema = dalSkipRowHeader.GetTableSchema(item.Parameter2.ToString(), null);
                                    //    //DataTable StaggingSchema = dalSkipRowHeader.GetTableSchema(item.Parameter2.ToString(), TryParseNullable(item.Parameter7));
                                    //    FinalTable = dalSkipRowHeader.ETL(FinalTable, StaggingSchema, int.Parse(item.Parameter6));
                                    //}

                                    //if it contains no header then no mapping will be made 



                                }
                                catch (Exception e)
                                {
                                    Model.ExecptionError.Id = item.ImportID;
                                    Model.ExecptionError.ReferenceError = "Step Order" + item.StepOrder + "-" + item.Action;
                                    Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.StackTrace;
                                    dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                                    dalException.LogEND(logh_k, "failure");
                                    break;
                                }
                                dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "success", null);
                                dalException.LogEND(logh_k, "success");
                            }
                            break;
                        case "SQL":
                            dalSQL SQL = new dalSQL();

                            //logh_k = dalException.LogStart(item.Action + item.ImportName);
                            if (Model.ExecptionError.Id == item.ImportID && Model.ExecptionError.ReferenceError != null)
                            {
                                //dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", "Gracefully failed due to error in  " + Model.ExecptionError.ReferenceError);
                                //dalException.LogEND(logh_k, "failure");
                                break;
                            }

                            else
                            {
                                try
                                {
                                    item.Parameter1 = item.Parameter1.Substring(item.Parameter1.LastIndexOf(':') + 1);
                                    item.Parameter7 = item.Parameter7.Substring(item.Parameter7.LastIndexOf(':') + 1);
                                    string ErrMSg = SQL.ExecuteSQL(item.Parameter1, TryParseNullable(item.Parameter7));
                                }
                                catch (Exception e)
                                {
                                    Model.ExecptionError.Id = item.ImportID;
                                    Model.ExecptionError.ReferenceError = "Step Order" + item.StepOrder + "-" + item.Action;
                                    Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.StackTrace;
                                    dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                                    dalException.LogEND(logh_k, "failure");
                                    break;
                                }

                                dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "success", null);
                                dalException.LogEND(logh_k, "success");
                            }


                            break;

                        case "Validation":
                            dalValidation dalValidation = new dalValidation();
                            try
                            {
                                item.Parameter1 = item.Parameter1 != null ? item.Parameter1.Substring(item.Parameter1.LastIndexOf(':') + 1) : null;

                                string Msg = dalValidation.ValidationStepOne(TryParseNullable(item.Parameter1));
                                string result = dalValidation.ValidationStepTwo(TryParseNullable(item.Parameter1));

                                if (!string.IsNullOrEmpty(result))
                                {
                                    throw new NullReferenceException("Severe Error Count>0");
                                }

                            }
                            catch (Exception e)
                            {
                                Model.ExecptionError.Id = item.ImportID;
                                Model.ExecptionError.ReferenceError = "Step Order" + item.StepOrder + "-" + item.Action;
                                Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.StackTrace;
                                dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                                dalException.LogEND(logh_k, "failure");
                                break;
                            }
                            dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "success", null);
                            dalException.LogEND(logh_k, "success");
                            break;
                        default:

                            break;
                    }
                }
                catch (Exception e)
                {
                    string MSG = e.Message;
                }

            }

            return View();
        }
        public int? TryParseNullable(string val)
        {
            int outValue;
            return int.TryParse(val, out outValue) ? (int?)outValue : null;
        }


        public ActionResult Test()
        {


            DataTable DataTable1 = new DataTable();
            DataTable DataTable2 = new DataTable();
            DataTable1.PrimaryKey = new DataColumn[] { DataTable1.Columns["TARGET"] };
            DataTable2.PrimaryKey = new DataColumn[] { DataTable2.Columns["TARGET"] };
            DataTable1.Merge(DataTable2);
            var dt = new DataTable();

            var tfp = new TextFieldParser(@"C:\\Test\SampleText.txt")
            {
                Delimiters = new[] { "," },
                HasFieldsEnclosedInQuotes = true,
                TrimWhiteSpace = true
            };

            using (tfp)
            {
                if (!tfp.EndOfData)
                {
                    string[] fields = tfp.ReadFields();

                    dt.Columns.AddRange(fields.Select(f => new DataColumn(f)).ToArray());

                    while (!tfp.EndOfData)
                    {
                        fields = tfp.ReadFields();

                        dt.Rows.Add(fields);
                    }
                }
            }
            return View();
        }



    }
}