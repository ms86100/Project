﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.Models
{
    public class C_ImportMap
    {
        public int Map_k { get; set; }
        public int ImportMapHeader_k { get; set; }
        public string FromField { get; set; }
        public int ToField { get; set; }
      
    }
}