﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;

namespace FUE.Web.DataAccess
{
    public class dalSendEmail
    {

        public void SendEmail(string Process, string Error, string Order)
        {
            try
            {
                using (var smtpClient = new SmtpClient("smtp.gmail.com", 587))
                {
                    smtpClient.UseDefaultCredentials = false;
                    smtpClient.Credentials = new NetworkCredential()
                    {
                        UserName = "noreplyfue@gmail.com",
                        Password = "UNIpay@123",
                    };
                    smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpClient.EnableSsl = true;
                  
                    //Oops: from/recipients switched around here...
                    //smtpClient.Send("targetemail@targetdomain.xyz", "myemail@gmail.com", "Account verification", body);
                    string ErrorMsg = "Unable to process step" + " " + Order + ". " + Process +" "+ "failing gracefully with the "+" " + Error + " "+"Exception"; 
                    //smtpClient.Send("noreplyfue@gmail.com", "heshy@vestracare.com", "File Upload Engine", ErrorMsg);
                }
            }

            catch (Exception e)
            {
                throw new Exception(e.ToString() + e.Message);
            }
        }
    }
}