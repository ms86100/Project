﻿using FUE.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.ViewModels
{
    public class MstAPIManageModel
    {
        public ExceptionErrorModel ExecptionError { get; set; }
        public IEnumerable<utblMstSampleImport> MstSampleImport { get; set; }
        public IEnumerable<MstStepsExecutionView> MstSteps { get; set; }
        public IEnumerable<utblMstStep> utblMstSteps { get; set; }
        public List<MstMappingTable> MstMapping { get; set; }
        public utblMstConnection utblMstConnections { get; set; }
    }
}