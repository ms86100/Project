﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.ViewModels
{
    public class MstImportMapHeaderViewModel
    {
        public int importMapHeader_k { get; set; }
        public string importMapName { get; set; }
    }
}