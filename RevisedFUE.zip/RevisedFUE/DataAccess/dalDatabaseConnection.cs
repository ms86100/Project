﻿using FUE.Web.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace FUE.Web.DataAccess
{
    public class dalDatabaseConnection
    {

        public static string ConnectionStrings(int? ConnectionID)
        {

            EFDBContext _db = new EFDBContext();
            utblMstDatabaseConnection Conn = new utblMstDatabaseConnection();
            string connectionString = string.Empty;
            try
            {
                var parConnectionID = new SqlParameter("@ConnectionID", ConnectionID);
                Conn = _db.Database.SqlQuery<utblMstDatabaseConnection>("SELECT * from utblMstDatabaseConnections Where ConnectionID=@ConnectionID", parConnectionID).FirstOrDefault();
                connectionString = "Data Source=" + Conn.DataSource + ";Initial Catalog=" + Conn.Catalog + "; user id = " + Conn.User_id + "; password=" + Conn.Password + "";
            }
            catch (Exception)
            {
                connectionString = ConfigurationManager.ConnectionStrings["EFDBContext"].ConnectionString;
                return connectionString;
            }
            return connectionString;
        }


        public static string GetConnectionData(int? ConnectionID)
        {
            EFDBContext _db = new EFDBContext();
            utblMstDatabaseConnection Conn = new utblMstDatabaseConnection();
            string connectionString = string.Empty;
            try
            {
                var parConnectionID = new SqlParameter("@ConnectionID", ConnectionID);
                Conn = _db.Database.SqlQuery<utblMstDatabaseConnection>("SELECT * from utblMstDatabaseConnections Where ConnectionID=@ConnectionID", parConnectionID).FirstOrDefault();
                //connectionString = "Data Source=" + Conn.DataSource + ";Initial Catalog=" + Conn.Catalog + "; user id = " + Conn.User_id + "; password=" + Conn.Password + "";
            }
            catch (Exception)
            {
                return null;
            }
            return Conn.Catalog;
        }

    }
}