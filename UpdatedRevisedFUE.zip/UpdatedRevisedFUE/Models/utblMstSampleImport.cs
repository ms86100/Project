﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FUE.Web.Models
{
    public class utblMstSampleImport
    {
        [Key]
        public int Id { get; set; }
        public string Action { get; set; }
        public string Parameter { get; set; }
        public string SourceTable { get; set; }
        public string APIDataSource { get; set; }
        public DateTime? LastExecution { get; set; }
        public string Status { get; set; }
        public string Description { get; set; }
    }
}