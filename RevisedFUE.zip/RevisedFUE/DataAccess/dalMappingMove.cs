﻿using FUE.Web.Models;
using FUE.Web.ViewModels;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using static FUE.Web.DataAccess.dalAPI;

namespace FUE.Web.DataAccess
{
    public class dalMappingMove
    {

        EFDBContextPROD _db = new EFDBContextPROD();
        public bool CheckIfTableExist(string tableName, int? ConnectionID)
        {
            int result = 0;
            string CS = dalDatabaseConnection.ConnectionStrings(ConnectionID);
            EFDDGeneric _db = new EFDDGeneric(CS);
            var parTableName = new SqlParameter("@TableName", tableName);
            result = _db.Database.SqlQuery<int>("select count (*) from information_schema.tables  where table_name =@TableName", parTableName).FirstOrDefault();
            return result == 0 ? false : true;
        }
        public DataTable GetTableSchemaStagging(string tableName ,int? ConnectionID)
        {
            //string _connectionStringStagging = ConfigurationManager.ConnectionStrings["EFDBContext"].ConnectionString;
            string CS = dalDatabaseConnection.ConnectionStrings(ConnectionID);
          
            string query = string.Format("SELECT TOP 0 * FROM {0}", tableName);
            using (SqlConnection localSqlConn = new SqlConnection(CS))
            {
                DataSet ds = new DataSet();

                SqlCommand sqlCmd = new SqlCommand(query, localSqlConn);
                SqlDataAdapter sda = new SqlDataAdapter(sqlCmd);

                sda.FillSchema(ds, SchemaType.Source, tableName);
                sda.Fill(ds, tableName);

                sda.Dispose();

                DataTable dt = ds.Tables[0];
                return dt;
            }
        }
        public DataTable GetTableSchemaProduction(string tableName, int? ConnectionID)
        {
            string CS = dalDatabaseConnection.ConnectionStrings(ConnectionID);

            //string _connectionStringProduction = ConfigurationManager.ConnectionStrings["EFDBContextPROD"].ConnectionString;

            string query = string.Format("SELECT TOP 0 * FROM {0}", tableName);

            using (SqlConnection localSqlConn = new SqlConnection(CS))
            {
                DataSet ds = new DataSet();

                SqlCommand sqlCmd = new SqlCommand(query, localSqlConn);
                SqlDataAdapter sda = new SqlDataAdapter(sqlCmd);

                sda.FillSchema(ds, SchemaType.Source, tableName);
                sda.Fill(ds, tableName);

                sda.Dispose();

                DataTable dt = ds.Tables[0];
                return dt;
            }
        }
        public DataTable StaggingToProductionSchemaResolver(DataTable Stagging, DataTable Production)
        {
            DataTable dt = null;

            foreach (DataColumn DC in Stagging.Columns)
            {
                foreach (DataColumn PDC in Production.Columns)
                {

                }
            }

            return dt;
        }
        public string GetImportMapTableHeaderTable(int ImportMapHeaderID)
        {
            string results;
            EFDBContext _db = new EFDBContext();
            var parImportMapHeaderID = new SqlParameter("@ImportMapHeaderID", ImportMapHeaderID);
            results = _db.Database.SqlQuery<string>("select DISTINCT ImportMapName from utblMstImportMapHeaders WHERE ImportMapHeaderID=@ImportMapHeaderID", parImportMapHeaderID).FirstOrDefault();
            return results;
        }
        public DataTable ProductionMappingResolver(DataTable dt, List<MstMappingTable> Fields, string TableTo, int? DbConnectionID)
        {

            string CS = dalDatabaseConnection.ConnectionStrings(DbConnectionID);
            EFDDGeneric _db = new EFDDGeneric(CS);



            foreach (DataColumn DC in dt.Columns)
            {
                foreach (var item in Fields)
                {
                    if (DC.ColumnName == item.FromField)
                    {
                        dt.Columns[item.FromField].ColumnName = item.ToField;
                        string FromColumn = TableTo + "." + item.FromField;
                        string ToColumn = item.ToField;
                        dt.AcceptChanges();
                        //var parTableAndColumnName = new SqlParameter("@TableAndColumnName", FromColumn);
                        //var parNewColumnName = new SqlParameter("@NewColumnName", ToColumn);
                        //List<string> result = _db.Database.SqlQuery<List<string>>("udspMstColumnRename @TableAndColumnName,@NewColumnName", parTableAndColumnName, parNewColumnName).FirstOrDefault();

                    }
                }


            }
            return dt;
        }

        public string CreateTableProgramitacally(DataTable table, string SourceTable, int? ConnectionID)
        {
            SPErrorViewModel objStatus = new SPErrorViewModel();
            string CS = dalDatabaseConnection.ConnectionStrings(ConnectionID);
            EFDDGeneric _db = new EFDDGeneric(CS);

            string exceptionMsg = string.Empty;
            string SQL = CreateTABLE(table, SourceTable);
            try
            {
                string TableError = _db.Database.ExecuteSqlCommand(SQL).ToString();
                if (TableError == "-1")
                {
                    objStatus.ErrorMessage = "Successful";
                }
                else
                {
                    objStatus.ErrorMessage = "Duplicate data found and operation revoked";
                }

            }
            catch (Exception e)
            {

                objStatus.ErrorMessage = e.Message;

            }
            return objStatus.ErrorMessage;
        }



        //public string CreateTableProgramitacally(DataTable table, string SourceTable)
        //{
        //    SPErrorViewModel objStatus = new SPErrorViewModel();
        //    string exceptionMsg = string.Empty;
        //    string SQL = CreateTABLE(table, SourceTable);
        //    try
        //    {
        //        string TableError = _db.Database.ExecuteSqlCommand(SQL).ToString();
        //        if (TableError.ToString() == "-1")
        //        {
        //            objStatus.ErrorMessage = "Successful";
        //        }
        //        else
        //        {
        //            objStatus.ErrorMessage = "Duplicate data found and operation revoked";
        //        }

        //    }
        //    catch (Exception e)
        //    {

        //        objStatus.ErrorMessage = e.Message;

        //    }
        //    return objStatus.ErrorMessage;
        //}
        public string CreateTABLE(DataTable table, string SourceTable)
        {

            string tableName = SourceTable;

            string sqlsc, indexsc;
            string Indexname = tableName + "Index ";
            //table.PrimaryKey = new DataColumn[] { table.Columns[0] };
            //indexsc = "CREATE UNIQUE NONCLUSTERED INDEX " + Indexname + "ON " + "[dbo]." + tableName + "";
            //indexsc += "Ecode ASC, Months ASC, Years ASC )";
            sqlsc = "CREATE TABLE " + tableName + "(";
            for (int i = 0; i < table.Columns.Count; i++)
            {
                sqlsc += "\n [" + table.Columns[i].ColumnName + "] ";
                string columnType = table.Columns[i].DataType.ToString();
                switch (columnType)
                {
                    case "System.Int32":
                        sqlsc += " int ";
                        break;
                    case "System.Int64":
                        sqlsc += " bigint ";
                        break;
                    case "System.Int16":
                        sqlsc += " smallint";
                        break;
                    case "System.Byte":
                        sqlsc += " tinyint";
                        break;
                    case "System.Decimal":
                        sqlsc += " decimal ";
                        break;
                    case "System.DateTime":
                        sqlsc += " datetime ";
                        break;
                    case "System.String":
                    default:
                        sqlsc += string.Format(" nvarchar({0}) ", table.Columns[i].MaxLength == -1 ? "250" : table.Columns[i].MaxLength.ToString());
                        break;
                }
                if (table.Columns[i].AutoIncrement)
                    sqlsc += " IDENTITY(" + table.Columns[i].AutoIncrementSeed.ToString() + "," + table.Columns[i].AutoIncrementStep.ToString() + ") ";
                if (!table.Columns[i].AllowDBNull)
                    sqlsc += " NOT NULL ";


                sqlsc += ",";

            }

            sqlsc = sqlsc.Substring(0, sqlsc.Length - 1) + "\n)";
            return sqlsc;
            //+= indexsc;

        }

        public static string ConnectionStrings()
        {
            EFDBContext _db = new EFDBContext();
            utblMstDatabaseConnection Conn = new utblMstDatabaseConnection();
            string connectionString = string.Empty;
            try
            {

                Conn = _db.Database.SqlQuery<utblMstDatabaseConnection>("SELECT * from utblMstDatabaseConnections Where TYPE='Production'").FirstOrDefault();
                connectionString = "Data Source=" + Conn.DataSource + ";Initial Catalog=" + Conn.Catalog + "; user id = " + Conn.User_id + "; password=" + Conn.Password + "";
                //string connectionString = "Data Source=DEL1-LT2VWCRV2\\SQLEXPRESS;Initial Catalog=Prod_FileImportEngine; user id = sa; password=Welcome123";
                SqlConnection con = new SqlConnection(connectionString);
            }
            catch (Exception e)
            {
                return null;
            }
            return connectionString;
        }
    }
}