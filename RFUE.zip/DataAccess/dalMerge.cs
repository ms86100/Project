﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace FUE.Web.DataAccess
{
    public class dalMerge
    {

        public DataTable MergeDatatable(DataTable dt1, DataTable dt2, string PrimaryKey)
        {
            var table1 = new DataTable();

            dt1.PrimaryKey = new DataColumn[] { dt1.Columns[PrimaryKey] };
            dt1.Merge(dt2);
            return dt1;
        }

        public DataTable GetTableData(string TableName, int? Connection_k)
        {

            string CS = dalDatabaseConnection.ConnectionStrings(Connection_k);
            var parsourceTable = new SqlParameter("@TableName", TableName);


            var table = new DataTable();
            using (var da = new SqlDataAdapter("SELECT * FROM "+ TableName, CS))
            {
                da.Fill(table);
            }

          
            return table;
        }
    }
}