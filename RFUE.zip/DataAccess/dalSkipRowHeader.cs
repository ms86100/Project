﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace FUE.Web.DataAccess
{
    public class dalSkipRowHeader
    {
      
        public static DataTable RemoveRow(DataTable dtFromExternal, int SkipRowHeader)
        {
            try
            {
                if (SkipRowHeader > 0)
                {
                    for (int i = SkipRowHeader - 1; i >= 0; i--)
                    {
                        DataRow row = dtFromExternal.Rows[0];
                        dtFromExternal.Rows.Remove(row);

                    }
                }
                dtFromExternal.AcceptChanges();
                return dtFromExternal;
            }
            catch (Exception e)
            {
                return null;
            }
          
        }


    }
}