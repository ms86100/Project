﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.ViewModels
{
    public class COVID19NursingHome
    {
        // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
        public class Geolocation
        {
            public string type { get; set; }
            public List<double> coordinates { get; set; }
        }

        public class Roots
        {
            public DateTime week_ending { get; set; }
            public string federal_provider_number { get; set; }
            public string provider_name { get; set; }
            public string provider_address { get; set; }
            public string provider_city { get; set; }
            public string provider_state { get; set; }
            public string provider_zip_code { get; set; }
            public string submitted_data { get; set; }
            public string residents_weekly_admissions { get; set; }
            public string residents_total_admissions { get; set; }
            public string residents_weekly_confirmed { get; set; }
            public string residents_total_confirmed { get; set; }
            public string residents_weekly_suspected { get; set; }
            public string residents_total_suspected { get; set; }
            public string residents_weekly_all_deaths { get; set; }
            public string residents_total_all_deaths { get; set; }
            public string residents_weekly_covid_19 { get; set; }
            public string residents_total_covid_19 { get; set; }
            public string number_of_all_beds { get; set; }
            public string total_number_of_occupied { get; set; }
            public string staff_weekly_confirmed_covid { get; set; }
            public string staff_total_confirmed_covid { get; set; }
            public string staff_weekly_suspected_covid { get; set; }
            public string staff_total_suspected_covid { get; set; }
            public string staff_weekly_covid_19_deaths { get; set; }
            public string staff_total_covid_19_deaths { get; set; }
            public string weekly_resident_confirmed_covid_19_cases_per_1_000_residents { get; set; }
            public string weekly_resident_covid_19_deaths_per_1_000_residents { get; set; }
            public string total_resident_confirmed_covid_19_cases_per_1_000_residents { get; set; }
            public string total_resident_covid_19_deaths_per_1_000_residents { get; set; }
            public string county { get; set; }
            public Geolocation geolocation { get; set; }
            public string reporting_interval { get; set; }

            [JsonProperty(":@computed_region_dz63_q6gx")]
            public string ComputedRegionDz63Q6gx { get; set; }

            [JsonProperty(":@computed_region_ia25_mrsk")]
            public string ComputedRegionIa25Mrsk { get; set; }

            [JsonProperty(":@computed_region_p3pw_njwh")]
            public string ComputedRegionP3pwNjwh { get; set; }

            [JsonProperty(":@computed_region_x9pa_s2gq")]
            public string ComputedRegionX9paS2gq { get; set; }

            [JsonProperty(":@computed_region_vbss_8z7g")]
            public string ComputedRegionVbss8z7g { get; set; }
            public string total_residents_covid_19_deaths_as_a_percentage_of_confirmed_covid_19_cases { get; set; }
            public string passed_quality_assurance { get; set; }
            public string resident_access_to_testing { get; set; }
            public string laboratory_type_is_state { get; set; }
            public string laboratory_type_is_private { get; set; }
            public string laboratory_type_is_other { get; set; }
            public string shortage_of_nursing_staff { get; set; }
            public string shortage_of_clinical_staff { get; set; }
            public string shortage_of_aides { get; set; }
            public string shortage_of_other_staff { get; set; }
            public string any_current_supply_of_n95 { get; set; }
            public string one_week_supply_of_n95_masks { get; set; }
            public string any_current_supply_of_surgical { get; set; }
            public string one_week_supply_of_surgical { get; set; }
            public string any_current_supply_of_eye { get; set; }
            public string one_week_supply_of_eye { get; set; }
            public string any_current_supply_of_gowns { get; set; }
            public string one_week_supply_of_gowns { get; set; }
            public string any_current_supply_of_gloves { get; set; }
            public string one_week_supply_of_gloves { get; set; }
            public string any_current_supply_of_hand { get; set; }
            public string one_week_supply_of_hand { get; set; }
            public string ventilator_dependent_unit { get; set; }
            public string three_or_more_confirmed_covid_19_cases_this_week { get; set; }
            public string initial_confirmed_covid_19_case_this_week { get; set; }
            public string number_of_ventilators_in { get; set; }
            public string number_of_ventilators_in_1 { get; set; }
            public string any_current_supply_of { get; set; }
            public string one_week_supply_of_ventilator { get; set; }
            public string able_to_test_or_obtain_resources_to_test_all_current_residents_within_next_7_days { get; set; }
            public string reason_for_not_testing_residents_lack_of_ppe_for_personnel_ { get; set; }
            public string reason_for_not_testing_residents_lack_of_supplies { get; set; }
            public string reason_for_not_testing_residents_lack_of_access_to_laboratory { get; set; }
            public string reason_for_not_testing_residents_lack_of_access_to_trained_personnel_ { get; set; }
            public string reason_for_not_testing_residents_uncertainty_about_reimbursement { get; set; }
            public string reason_for_not_testing_residents_other { get; set; }
            public string during_past_two_weeks_average_time_to_receive_resident_test_results { get; set; }
            public string has_facility_performed_resident_tests_since_last_report { get; set; }
            public string tested_residents_with_new_signs_or_symptoms { get; set; }
            public string tested_asymptomatic_residents_in_a_unit_or_section_after_a_new_case { get; set; }
            public string tested_asymptomatic_residents_facility_wide_after_a_new_case { get; set; }
            public string tested_asymptomatic_residents_without_known_exposure_as_surveillance { get; set; }
            public string tested_another_subgroup_of_residents { get; set; }
            public string able_to_test_or_obtain_resources_to_test_all_staff_and_or_personnel_within_next_7_days { get; set; }
            public string reason_for_not_testing_staff_and_or_personnel_lack_of_ppe_for_personnel_ { get; set; }
            public string reason_for_not_testing_staff_and_or_personnel_lack_of_supplies { get; set; }
            public string reason_for_not_testing_staff_and_or_personnel_lack_of_access_to_laboratory { get; set; }
            public string reason_for_not_testing_staff_and_or_personnel_lack_of_access_to_trained_personnel_ { get; set; }
            public string reason_for_not_testing_staff_and_or_personnel_uncertainty_about_reimbursement { get; set; }
            public string reason_for_not_testing_staff_and_or_personnel_other { get; set; }
            public string during_past_two_weeks_average_time_to_receive_staff_and_or_personnel_test_results { get; set; }
            public string has_facility_performed_staff_and_or_personnel_tests_since_last_report { get; set; }
            public string tested_staff_and_or_personnel_with_new_signs_or_symptoms { get; set; }
            public string tested_asymptomatic_staff_and_or_personnel_in_a_unit_or_section_after_a_new_case { get; set; }
            public string tested_asymptomatic_staff_and_or_personnel_facility_wide_after_a_new_case { get; set; }
            public string tested_asymptomatic_staff_and_or_personnel_without_known_exposure_as_surveillance { get; set; }
            public string tested_another_subgroup_of_staff_and_or_personnel { get; set; }
            public string in_house_point_of_care_test_machine { get; set; }
            public string covid_19_point_of_care_tests_performed_on_residents_since_last_report { get; set; }
            public string covid_19_point_of_care_tests_performed_on_staff_and_or_personnel_since_last_report { get; set; }
            public string enough_supplies_to_test_all_staff_and_or_personnel_using_point_of_care_test_machine { get; set; }
            public string has_facility_performed_tests_since_last_report { get; set; }
            public string covid_19_non_point_of_care_tests_performed_on_residents_since_last_report { get; set; }
            public string covid_19_non_point_of_care_tests_performed_on_staff_and_or_personnel_since_last_report { get; set; }
            public string number_of_residents_with_a_new_positive_covid_19_test_result { get; set; }
            public string number_of_residents_with_a_new_positive_covid_19_test_result_with_positive_antigen_test_only { get; set; }
            public string number_of_residents_with_a_new_positive_covid_19_test_result_with_positive_naat_pcr_test_only { get; set; }
            public string number_of_residents_with_a_new_positive_covid_19_test_result_with_positive_antigen_test_and_negative_naat_pcr_test { get; set; }
            public string number_of_residents_with_a_new_positive_covid_19_test_result_with_any_other_combination_of_antigen_test_and_or_naat_pcr_test_with_at_least_one_positive_test { get; set; }
            public string number_of_residents_with_a_new_positive_covid_19_test_result_who_are_reinfected { get; set; }
            public string number_of_residents_with_a_new_positive_covid_19_test_result_who_are_reinfected_and_symptomatic { get; set; }
            public string number_of_residents_with_a_new_positive_covid_19_test_result_who_are_reinfected_and_asymptomatic { get; set; }
            public string number_of_residents_with_new_influenza { get; set; }
            public string number_of_residents_with_acute_respiratory_illness_symptoms_excluding_covid_19_and_or_influenza { get; set; }
            public string number_of_residents_with_confirmed_coinfection_with_influenza_and_covid_19 { get; set; }
            public string during_past_two_weeks_average_time_to_receive_covid_19_test_results_from_non_point_of_care_tests { get; set; }
            public string number_of_staff_and_or_personnel_with_a_new_positive_covid_19_test_result { get; set; }
            public string number_of_staff_and_or_personnel_with_a_new_positive_covid_19_test_result_with_positive_antigen_test_only { get; set; }
            public string number_of_staff_and_or_personnel_with_a_new_positive_covid_19_test_result_with_positive_naat_pcr_test_only { get; set; }
            public string number_of_staff_and_or_personnel_with_a_new_positive_covid_19_test_result_with_positive_antigen_test_and_negative_naat_pcr_test { get; set; }
            public string number_of_staff_and_or_personnel_with_a_new_positive_covid_19_test_result_with_any_other_combination_of_antigen_test_and_or_naat_pcr_test_with_at_least_one_positive_test { get; set; }
            public string number_of_staff_and_or_personnel_with_a_new_positive_covid_19_test_result_who_are_reinfected { get; set; }
            public string number_of_staff_and_or_personnel_with_a_new_positive_covid_19_test_result_who_are_reinfected_and_symptomatic { get; set; }
            public string number_of_staff_and_or_personnel_with_a_new_positive_covid_19_test_result_who_are_reinfected_and_asymptomatic { get; set; }
            public string number_of_staff_and_or_personnel_with_new_influenza { get; set; }
            public string number_of_staff_and_or_personnel_with_acute_respiratory_illness_symptoms_excluding_covid_19_and_or_influenza { get; set; }
            public string number_of_staff_and_or_personnel_with_confirmed_coinfection_with_influenza_and_covid_19 { get; set; }
            public string alcohol_based_hand_rub_abhr_available { get; set; }
            public string alcohol_based_hand_rub_abhr_no_longer_available_in_7_days { get; set; }
            public string n95_respirator_strategy_for_optimization { get; set; }
            public string n95_respirator_no_longer_available_in_7_days { get; set; }
            public string face_masks_strategy_for_optimization { get; set; }
            public string face_masks_no_longer_available_in_7_days { get; set; }
            public string eye_protection_strategy_for_optimization { get; set; }
            public string eye_protection_no_longer_available_in_7_days { get; set; }
            public string gowns_strategy_for_optimization { get; set; }
            public string gowns_no_longer_available_in_7_days { get; set; }
            public string gloves_strategy_for_optimization { get; set; }
            public string gloves_no_longer_available_in_7_days { get; set; }
            public string facility_would_like_assistance_outreach_for_staffing_shortages { get; set; }
            public string facility_would_like_assistance_outreach_for_personal_protective_equipment_ppe_ { get; set; }
            public string facility_would_like_assistance_outreach_for_testing_supply_shortages { get; set; }
            public string facility_would_like_assistance_outreach_for_infection_control_outbreak_management { get; set; }
            public string facility_would_like_assistance_outreach_for_staff_training { get; set; }
            public string facility_would_like_assistance_outreach_for_vaccine_access_residents_or_staff_ { get; set; }
        }


    }
}