﻿using FUE.Web.DataAccess;
using FUE.Web.ViewModels;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using FUE.Web.Models;
using ChoETL;
using Microsoft.VisualBasic.FileIO;

namespace FUE.Web.Controllers
{
    public class HomeController : Controller
    {
        dalAPI dal = new dalAPI();
        MstAPIManageModel Model = new MstAPIManageModel();
        public ActionResult Index(int? ImportID)
        {
            Model.MstSteps = dal.GetStepsExecutionDetails(ImportID);
            Model.ExecptionError = new ExceptionErrorModel();
            dalLogException dalException = new dalLogException();

            DataTable FinalTable = new DataTable();
            string ErrMsg = string.Empty;
            int logh_k = 0;
            int Import_id = 0;
            foreach (var item in Model.MstSteps)
            {

                if (item.Import_k != Import_id)
                {
                    logh_k = dalException.LogStart(item.ImportName + "-" + "id" + "{" + item.Import_k + "}");
                    Import_id = item.Import_k;
                }
                try
                {
                    switch (item.Action)
                    {
                        case "ImportAPI":

                            item.Parameter1 = item.Parameter1 != null ? item.Parameter1 : throw new NullReferenceException("Parameter1 is Null");
                            item.Parameter2 = item.Parameter2 != null ? item.Parameter2 : throw new NullReferenceException("Parameter2 is Null");
                            item.Parameter4 = item.Parameter4 != null ? item.Parameter4 : throw new NullReferenceException("Parameter4 is Null");

                            if (Model.ExecptionError.Id == item.Import_k && Model.ExecptionError.ReferenceError != null)
                                break;

                            FinalTable = new DataTable();
                            try
                            {
                                using (var webClient = new System.Net.WebClient())
                                {
                                    DataTable dt = new DataTable();
                                    var json = webClient.DownloadString(item.Parameter1.Trim());
                                    JArray jsonArray = JArray.Parse(json);
                                    for (int i = 0; i < jsonArray.Count; i++)
                                    {
                                        JObject data = JObject.Parse(jsonArray[i].ToString());
                                        using (var r = new ChoJSONReader(data))
                                        {
                                            dt = r.AsDataTable();
                                            FinalTable.Merge(dt);
                                            dt.AcceptChanges();
                                            FinalTable.AcceptChanges();
                                        }
                                    }

                                    item.Parameter2 = item.Parameter2.Substring(item.Parameter2.LastIndexOf(':') + 1);
                                    item.Parameter4 = item.Parameter4 != null ? item.Parameter4.Substring(item.Parameter4.LastIndexOf(':') + 1) : null;

                                    if (!string.IsNullOrEmpty(item.Parameter3))
                                    {
                                        item.Parameter3 = item.Parameter3.Substring(item.Parameter3.LastIndexOf(':') + 1);
                                        int? MapHeaderID = TryParseNullable(item.Parameter3);
                                        Model.MstMapping = dal.GetMappingData(MapHeaderID, null);
                                        //Model.MstMapping = dal.GetMappingData(MapHeaderID, TryParseNullable(item.Parameter4));
                                        FinalTable = dal.MappingResolver(FinalTable, Model.MstMapping, item.Parameter2);
                                    }
                                    ErrMsg = dal.CreateTableProgramitacally(FinalTable, item.Parameter2, TryParseNullable(item.Parameter4));
                                    //ErrMsg = dal.CreateTableProgramitacally(FinalTable, item.Parameter2);
                                    string Msg = dal.CreateMaptable(FinalTable, item.Parameter2, null);
                                    //string Msg = dal.CreateMaptable(FinalTable, item.Parameter2, TryParseNullable(item.Parameter4));

                                    //string Msg = dal.CreateMaptable(FinalTable, item.Parameter2);
                                    if (!string.IsNullOrEmpty(ErrMsg))//Table Already Exist or created successfully Simply Add data 
                                    {
                                        //string TVP = dal.TVP(FinalTable, item.Parameter2, null);
                                        string TVP = dal.TVP(FinalTable, item.Parameter2, TryParseNullable(item.Parameter4));
                                    }

                                }
                            }
                            catch (Exception e)
                            {


                                Model.ExecptionError.Id = item.Import_k;
                                Model.ExecptionError.ReferenceError = "Step Order" + item.StepOrder + "-" + item.Action;
                                Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.Message;
                                dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                                dalException.LogEND(logh_k, "failure");


                                dalSendEmail dalEmail = new dalSendEmail();
                                dalEmail.SendEmail(item.Action + item.ImportName, e.Message, item.StepOrder.ToString());

                                break;
                            }
                            dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "success", null);
                            dalException.LogEND(logh_k, "success");
                            break;

                        case "MappingMove":

                            item.Parameter1 = item.Parameter1 != null ? item.Parameter1 : throw new NullReferenceException("Parameter1 is Null");
                            item.Parameter2 = item.Parameter2 != null ? item.Parameter2 : throw new NullReferenceException("Parameter2 is Null");
                            item.Parameter4 = item.Parameter4 != null ? item.Parameter4 : throw new NullReferenceException("Parameter4 is Null");
                            item.Parameter5 = item.Parameter5 != null ? item.Parameter5 : throw new NullReferenceException("Parameter5 is Null");

                            if (Model.ExecptionError.Id == item.Import_k && Model.ExecptionError.ReferenceError != null)
                            {
                                break;
                            }

                            else
                            {
                                try
                                {
                                    dalMappingMove dalMappingMove = new dalMappingMove();
                                    string TableFrom = item.Parameter1.Substring(item.Parameter1.LastIndexOf(':') + 1);
                                    string TableTo = item.Parameter2.Substring(item.Parameter2.LastIndexOf(':') + 1);
                                    item.Parameter3 = item.Parameter3 != null ? item.Parameter3.Substring(item.Parameter3.LastIndexOf(':') + 1) : null;
                                    item.Parameter4 = item.Parameter4 != null ? item.Parameter4.Substring(item.Parameter4.LastIndexOf(':') + 1) : null;
                                    item.Parameter5 = item.Parameter5 != null ? item.Parameter5.Substring(item.Parameter5.LastIndexOf(':') + 1) : null;
                                    bool results = dalMappingMove.CheckIfTableExist(TableTo, TryParseNullable(item.Parameter5));
                                    if (results)
                                    {
                                        if (!string.IsNullOrEmpty(item.Parameter3))
                                        {
                                            DataTable ProductionSchema = dalMappingMove.GetTableSchemaProduction(TableTo, TryParseNullable(item.Parameter5));
                                            //DataTable ProductionSchema = dalMappingMove.GetTableSchemaProduction(TableFrom,TryParseNullable(item.Parameter4));
                                            //Model.MstMapping = dal.GetMappingData(TryParseNullable(item.Parameter3), TryParseNullable(item.Parameter4));
                                            Model.MstMapping = dal.GetMappingData(TryParseNullable(item.Parameter3), null);
                                            dalMappingMove.ProductionMappingResolver(ProductionSchema, Model.MstMapping, TableTo, TryParseNullable(item.Parameter5));
                                            string result = dal.StaggingMove(TableFrom, TableTo, TryParseNullable(item.Parameter4), TryParseNullable(item.Parameter5));
                                        }

                                        else
                                        {
                                            string result = dal.StaggingMove(TableFrom, TableTo, TryParseNullable(item.Parameter4), TryParseNullable(item.Parameter5));
                                        }
                                    }

                                    else
                                    {
                                        DataTable StaggingSchema = dalMappingMove.GetTableSchemaStagging(TableFrom, TryParseNullable(item.Parameter4));
                                        ErrMsg = dalMappingMove.CreateTableProgramitacally(StaggingSchema, TableTo, TryParseNullable(item.Parameter5));

                                        //newly added
                                        string Msg = dal.CreateMaptable(StaggingSchema, TableTo, null);

                                        //string Msg = dal.CreateMaptable(StaggingSchema, TableTo, TryParseNullable(item.Parameter5));


                                        if (!string.IsNullOrEmpty(ErrMsg))//Table Already Exist or created successfully Simply Add data 
                                        {
                                            string result = dal.StaggingMove(TableFrom, TableTo, TryParseNullable(item.Parameter4), TryParseNullable(item.Parameter5));
                                        }
                                    }
                                }
                                catch (Exception e)
                                {
                                    Model.ExecptionError.Id = item.Import_k;
                                    Model.ExecptionError.ReferenceError = "Step Order" + item.StepOrder + "-" + item.Action;
                                    Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.StackTrace;
                                    dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                                    dalException.LogEND(logh_k, "failure");

                                    dalSendEmail dalEmail = new dalSendEmail();
                                    dalEmail.SendEmail(item.Action + item.ImportName, e.Message, item.StepOrder.ToString());
                                    break;
                                }
                                dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "success", null);
                                dalException.LogEND(logh_k, "success");
                            }


                            break;
                        case "FTP":
                            dalGetFTP dalFTP = new dalGetFTP();
                            if (Model.ExecptionError.Id == item.Import_k && Model.ExecptionError.ReferenceError != null)
                            {
                                break;
                            }
                            else
                            {

                                Model.utblMstConnections = new C_ConnectionFTP();
                                try
                                {
                                    item.Parameter1 = item.Parameter1 != null ? item.Parameter1.Substring(item.Parameter1.LastIndexOf(':') + 1) : null;
                                    item.Parameter2 = item.Parameter2 != null ? item.Parameter2.Substring(item.Parameter2.LastIndexOf(':') + 1) : null;
                                    item.Parameter4 = item.Parameter4 != null ? item.Parameter4.Substring(item.Parameter4.LastIndexOf(':') + 1) : null;
                                    Model.utblMstConnections = dalFTP.MstGetFTPConnection(TryParseNullable(item.Parameter1));
                                    dalFTP.GETFTPFILE(Model.utblMstConnections.Url, Model.utblMstConnections.UserName, Model.utblMstConnections.Password, item.Parameter4);
                                }
                                catch (Exception e)
                                {
                                    Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.StackTrace;
                                    dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                                    dalException.LogEND(logh_k, "failure");

                                    dalSendEmail dalEmail = new dalSendEmail();
                                    dalEmail.SendEmail(item.Action + item.ImportName, e.Message, item.StepOrder.ToString());
                                    break;
                                }
                            }
                            break;
                        case "Importdelimitedfile":
                            dalGetDelimitedFiles dalDelimited = new dalGetDelimitedFiles();

                            item.Parameter1 = item.Parameter1 != null ? item.Parameter1 : throw new NullReferenceException("Parameter1 is Null");
                            item.Parameter2 = item.Parameter2 != null ? item.Parameter2 : throw new NullReferenceException("Parameter2 is Null");
                            item.Parameter4 = item.Parameter4 != null ? item.Parameter4 : throw new NullReferenceException("Parameter4 is Null");

                            if (Model.ExecptionError.Id == item.Import_k && Model.ExecptionError.ReferenceError != null)
                            {

                                break;
                            }
                            else
                            {

                                try
                                {
                                    if (!item.Parameter1.Contains("http"))
                                    {
                                        item.Parameter1 = item.Parameter1 != null ? item.Parameter1.Substring(item.Parameter1.LastIndexOf(':') + 1) : null;
                                    }

                                    item.Parameter2 = item.Parameter2 != null ? item.Parameter2.Substring(item.Parameter2.LastIndexOf(':') + 1) : null;
                                    item.Parameter3 = item.Parameter3 != null ? item.Parameter3.Substring(item.Parameter3.LastIndexOf(':') + 1) : null;
                                    item.Parameter4 = item.Parameter4 != null ? item.Parameter4.Substring(item.Parameter4.LastIndexOf(':') + 1) : null;
                                    item.Parameter5 = item.Parameter5 != null ? item.Parameter5.Substring(item.Parameter5.LastIndexOf(':') + 1) : null;
                                    item.Parameter6 = item.Parameter6 != null ? item.Parameter6.Substring(item.Parameter6.LastIndexOf(':') + 1) : null;
                                    item.Parameter7 = item.Parameter7 != null ? item.Parameter7.Substring(item.Parameter7.LastIndexOf(':') + 1) : null;
                                    string TempFIlePathToDump = Server.MapPath("~/Uploads/");
                                    FinalTable = dalDelimited.GetFile(item.Parameter1, item.Parameter2, item.Parameter5, TempFIlePathToDump, TryParseNullable(item.Parameter6));
                                    if (!string.IsNullOrEmpty(item.Parameter7))
                                    {
                                        FinalTable = dalDelimited.EscapeCharacter(FinalTable, item.Parameter7);
                                    }
                                    if (!string.IsNullOrEmpty(item.Parameter3))
                                    {
                                        int? MapHeaderID = TryParseNullable(item.Parameter3);
                                        Model.MstMapping = dal.GetMappingData(MapHeaderID, null);
                                        FinalTable = dal.MappingResolver(FinalTable, Model.MstMapping, item.Parameter2);
                                    }

                                    ErrMsg = dal.CreateTableProgramitacally(FinalTable, item.Parameter2, TryParseNullable(item.Parameter4));
                                    string Msg = dal.CreateMaptable(FinalTable, item.Parameter2, null);
                                    if (!string.IsNullOrEmpty(ErrMsg))//Table Already Exist or created successfully Simply Add data 
                                    {
                                        string TVP = dal.TVP(FinalTable, item.Parameter2, TryParseNullable(item.Parameter4));
                                    }


                                    //if (TryParseNullable(item.Parameter6) != null && TryParseNullable(item.Parameter6) > 0)
                                    //{
                                    //    DataTable StaggingSchema = dalSkipRowHeader.GetTableSchema(item.Parameter2.ToString(), null);
                                    //    //DataTable StaggingSchema = dalSkipRowHeader.GetTableSchema(item.Parameter2.ToString(), TryParseNullable(item.Parameter7));
                                    //    FinalTable = dalSkipRowHeader.ETL(FinalTable, StaggingSchema, int.Parse(item.Parameter6));
                                    //}

                                    //if it contains no header then no mapping will be made 



                                }
                                catch (Exception e)
                                {
                                    Model.ExecptionError.Id = item.Import_k;
                                    Model.ExecptionError.ReferenceError = "Step Order" + item.StepOrder + "-" + item.Action;
                                    Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.Message;
                                    dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                                    dalException.LogEND(logh_k, "failure");

                                    dalSendEmail dalEmail = new dalSendEmail();
                                    dalEmail.SendEmail(item.Action + item.ImportName, e.Message, item.StepOrder.ToString());
                                    break;
                                }
                                dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "success", null);
                                dalException.LogEND(logh_k, "success");
                            }
                            break;
                        case "SQL":
                            dalSQL SQL = new dalSQL();

                            item.Parameter1 = item.Parameter1 != null ? item.Parameter1 : throw new NullReferenceException("Parameter1 is Null");
                            item.Parameter2 = item.Parameter2 != null ? item.Parameter2 : throw new NullReferenceException("Parameter2 is Null");
                            if (Model.ExecptionError.Id == item.Import_k && Model.ExecptionError.ReferenceError != null)
                            {
                                break;
                            }

                            else
                            {
                                try
                                {
                                    item.Parameter1 = item.Parameter1.Substring(item.Parameter1.LastIndexOf(':') + 1);
                                    item.Parameter2 = item.Parameter2.Substring(item.Parameter2.LastIndexOf(':') + 1);
                                    string ErrMSg = SQL.ExecuteSQL(item.Parameter1, TryParseNullable(item.Parameter2));
                                }
                                catch (Exception e)
                                {
                                    Model.ExecptionError.Id = item.Import_k;
                                    Model.ExecptionError.ReferenceError = "Step Order" + item.StepOrder + "-" + item.Action;
                                    Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.Message;
                                    dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                                    dalException.LogEND(logh_k, "failure");

                                    dalSendEmail dalEmail = new dalSendEmail();
                                    dalEmail.SendEmail(item.Action + item.ImportName, e.Message, item.StepOrder.ToString());
                                    break;
                                }

                                dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "success", null);
                                dalException.LogEND(logh_k, "success");
                            }


                            break;

                        case "Validation":
                            dalValidation dalValidation = new dalValidation();
                            item.Parameter1 = item.Parameter1 != null ? item.Parameter1 : throw new NullReferenceException("Parameter1 is Null");
                            try
                            {
                                item.Parameter1 = item.Parameter1 != null ? item.Parameter1.Substring(item.Parameter1.LastIndexOf(':') + 1) : null;

                                string Msg = dalValidation.ValidationStepOne(TryParseNullable(item.Parameter1));
                                string result = dalValidation.ValidationStepTwo(TryParseNullable(item.Parameter1));

                                if (!string.IsNullOrEmpty(result))
                                {
                                    throw new NullReferenceException("Severe Error Count>0");
                                }

                            }
                            catch (Exception e)
                            {
                                Model.ExecptionError.Id = item.Import_k;
                                Model.ExecptionError.ReferenceError = "Step Order" + item.StepOrder + "-" + item.Action;
                                Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.Message;
                                dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                                dalException.LogEND(logh_k, "failure");

                                dalSendEmail dalEmail = new dalSendEmail();
                                dalEmail.SendEmail(item.Action + item.ImportName, e.Message, item.StepOrder.ToString());
                                break;
                            }
                            dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "success", null);
                            dalException.LogEND(logh_k, "success");
                            break;
                        case "Merge":
                            if (Model.ExecptionError.Id == item.Import_k && Model.ExecptionError.ReferenceError != null)
                            {

                                break;
                            }
                            else
                            {

                                try
                                {
                                    dalMerge dalMerge = new dalMerge();

                                    item.Parameter1 = item.Parameter1 != null ? item.Parameter1 : throw new NullReferenceException("Parameter1 is Null");
                                    item.Parameter2 = item.Parameter2 != null ? item.Parameter2 : throw new NullReferenceException("Parameter2 is Null");
                                    item.Parameter3 = item.Parameter3 != null ? item.Parameter3 : throw new NullReferenceException("Parameter2 is Null");
                                    item.Parameter4 = item.Parameter4 != null ? item.Parameter4 : throw new NullReferenceException("Parameter4 is Null");

                                    item.Parameter1 = item.Parameter1 != null ? item.Parameter1.Substring(item.Parameter1.LastIndexOf(':') + 1) : null;
                                    item.Parameter2 = item.Parameter2 != null ? item.Parameter2.Substring(item.Parameter2.LastIndexOf(':') + 1) : null;
                                    item.Parameter3 = item.Parameter3 != null ? item.Parameter3.Substring(item.Parameter3.LastIndexOf(':') + 1) : null;
                                    item.Parameter4 = item.Parameter4 != null ? item.Parameter4.Substring(item.Parameter4.LastIndexOf(':') + 1) : null;
                                    item.Parameter5 = item.Parameter5 != null ? item.Parameter5.Substring(item.Parameter5.LastIndexOf(':') + 1) : null;
                                    item.Parameter6 = item.Parameter6 != null ? item.Parameter6.Substring(item.Parameter6.LastIndexOf(':') + 1) : null;

                                    DataTable Dt1 = dalMerge.GetTableData(item.Parameter1, TryParseNullable(item.Parameter4));
                                    DataTable Dt2 = dalMerge.GetTableData(item.Parameter2, TryParseNullable(item.Parameter5));
                                    string Pk = item.Parameter3;

                                    FinalTable = dalMerge.MergeDatatable(Dt1, Dt2, Pk);

                                    if (!(item.Parameter6 == item.Parameter4) || (item.Parameter6 == item.Parameter5))
                                    {
                                        ErrMsg = dal.CreateTableProgramitacally(FinalTable, item.Parameter2, TryParseNullable(item.Parameter6));
                                    }
                                    //string Msg = dal.CreateMaptable(FinalTable, item.Parameter2, null);
                                    if (!string.IsNullOrEmpty(ErrMsg))//Table Already Exist or created successfully Simply Add data 
                                    {
                                        string TVP = dal.TVP(FinalTable, item.Parameter1, TryParseNullable(item.Parameter6));
                                    }
                                }
                                catch (Exception e)
                                {
                                    Model.ExecptionError.Id = item.Import_k;
                                    Model.ExecptionError.ReferenceError = "Step Order" + item.StepOrder + "-" + item.Action;
                                    Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.Message;
                                    dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                                    dalException.LogEND(logh_k, "failure");

                                    dalSendEmail dalEmail = new dalSendEmail();
                                    dalEmail.SendEmail(item.Action + item.ImportName, e.Message, item.StepOrder.ToString());
                                    break;

                                }
                                dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "success", null);
                                dalException.LogEND(logh_k, "success");

                            }

                            break;
                        case "SSIS":
                            dalSSIS dalSSIS = new dalSSIS();
                            item.Parameter1 = item.Parameter1 != null ? item.Parameter1 : throw new NullReferenceException("Parameter1 is Null");
                            //item.Parameter2 = item.Parameter2 != null ? item.Parameter2 : throw new NullReferenceException("Parameter2 is Null");
                            if (Model.ExecptionError.Id == item.Import_k && Model.ExecptionError.ReferenceError != null)
                            {
                                break;
                            }
                            else
                            {
                                try
                                {
                                    item.Parameter1 = item.Parameter1.Substring(item.Parameter1.LastIndexOf(':') + 1);
                                    //item.Parameter2 = item.Parameter2.Substring(item.Parameter2.LastIndexOf(':') + 1);
                                    //string ErrMSg = dalSSIS.RunSSISPacakage(item.Parameter1, TryParseNullable(item.Parameter2));
                                    string ErrMSg = dalSSIS.RunSSISPacakage(item.Parameter1,null);
                                }
                                catch (Exception e)
                                {
                                    Model.ExecptionError.Id = item.Import_k;
                                    Model.ExecptionError.ReferenceError = "Step Order" + item.StepOrder + "-" + item.Action;
                                    Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.Message;
                                    dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                                    dalException.LogEND(logh_k, "failure");

                                    dalSendEmail dalEmail = new dalSendEmail();
                                    dalEmail.SendEmail(item.Action + item.ImportName, e.Message, item.StepOrder.ToString());
                                    break;
                                }

                                dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "success", null);
                                dalException.LogEND(logh_k, "success");
                            }


                            break;

                        default:

                            break;
                    }
                }
                catch (Exception e)
                {

                    Model.ExecptionError.Id = item.Import_k;
                    Model.ExecptionError.ReferenceError = "Step Order" + item.StepOrder + "-" + item.Action;
                    Model.ExecptionError.ErrorMessage = "Exception In " + item.Action + item.ImportName + "-" + e.Message;
                    dalException.LogAdd(logh_k, null, "Step" + item.StepOrder, "failure", Model.ExecptionError.ErrorMessage);
                    dalException.LogEND(logh_k, "failure");

                    dalSendEmail dalEmail = new dalSendEmail();
                    dalEmail.SendEmail(item.Action + item.ImportName, e.Message, item.StepOrder.ToString());
                    break;
                }

            }

            return View();
        }
        public int? TryParseNullable(string val)
        {
            int outValue;
            return int.TryParse(val, out outValue) ? (int?)outValue : null;
        }


        public ActionResult Test()
        {
            //dalSSIS dal = new dalSSIS();
            //dal.RunLoad();

            DataTable DataTable1 = new DataTable();
            DataTable DataTable2 = new DataTable();
            DataTable1.PrimaryKey = new DataColumn[] { DataTable1.Columns["C_k"] };
            DataTable2.PrimaryKey = new DataColumn[] { DataTable2.Columns["C_k"] };


            //DataTable1.Columns.Add("C_k");
            //DataTable1.Columns.Add("Name");
            //DataTable1.Columns.Add("Email");
            //DataTable1.Columns.Add("Phone");


            ////-----------------------
            //DataTable2.Columns.Add("C_k");
            //DataTable2.Columns.Add("Name");
            //DataTable2.Columns.Add("Email");
            //DataTable2.Columns.Add("Phone");

            //-------------------------------



            //for (int i = 0; i < 5; i++)
            //{
            //    DataRow dr1 = DataTable1.NewRow();
            //    dr1["C_k"] = i.ToString();
            //    dr1["Name"] = "Sagar" + (i).ToString();
            //    dr1["Email"] = "ms86100" + (i).ToString();
            //    dr1["Phone"] = (i * 1000).ToString();
            //    DataTable1.Rows.Add(dr1);

            //}

            //DataTable1.Rows[1]["Name"] = "Sagar Sharma DT1";
            //DataTable1.Rows[1]["Email"] = "ms86100@gmail.com DT1";


            //for (int i = 0; i < 10; i++)
            //{
            //    DataRow dr2 = DataTable2.NewRow();
            //    dr2["C_k"] = i.ToString();
            //    dr2["Name"] = "Sagar" + (i).ToString();
            //    dr2["Email"] = "ms86100" + (i).ToString();
            //    dr2["Phone"] = (i * 1000).ToString();
            //    DataTable2.Rows.Add(dr2);
            //}
            //DataTable2.Rows[0]["Name"] = "Sagar Sharma";
            //DataTable2.Rows[0]["Email"] = "ms86100@gmail.com";



            var columnId = new DataColumn("ID", typeof(int));
            var columnName = new DataColumn("Name", typeof(string));
            var table1 = new DataTable();
            table1.Columns.AddRange(new[] { columnId, columnName });
            table1.PrimaryKey = new[] { columnId };
            table1.Rows.Add(1, "A");
            table1.Rows.Add(2, "B");
            table1.Rows.Add(3, "C");
            table1.Rows.Add(4, "D");
            table1.Rows.Add(5, "E");

            var table2 = table1.Clone();
            table2.Rows.Add(1, "Z");
            table2.Rows.Add(2, "Y");
            table2.Rows.Add(3, "C");
            table2.Rows.Add(4, "D");
            table2.Rows.Add(5, "E");
            table2.Rows.Add(6, "F");
            table2.Rows.Add(7, "G");
            table2.Rows.Add(8, "H");
            table2.Rows.Add(9, "I");
            var table3 = table1.Copy();
            table3.AcceptChanges();
            table3.Merge(table2);


            dalMerge dal = new dalMerge();

            DataTable dtm = dal.MergeDatatable(table1, table2, "ID");

            //----------------------------------------------------------------------------------------



            var table4 = table1.Clone();

            table4.Rows.Add(1, "Z");
            table4.Rows.Add(2, "Y");
            table4.Rows.Add(3, "J");
            table4.Rows.Add(4, "K");
            table4.Rows.Add(5, "L");
            table4.Rows.Add(6, "M");
            table4.Rows.Add(7, "N");
            table4.Rows.Add(8, "O");
            table4.Rows.Add(9, "P");
            var table5 = table1.Copy();
            table4.AcceptChanges();
            table4.Merge(table3);

            //-----------------------------------------------------------------------------------


            var distinctRows = from row in table3.AsEnumerable()
                               where row.RowState != DataRowState.Modified
                               select row;

            var distintTable = distinctRows.CopyToDataTable();
            //------------------------------------------------------------------------------------------

            return View();
        }



    }
}