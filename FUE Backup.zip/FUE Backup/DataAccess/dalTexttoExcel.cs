﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;

using Microsoft.VisualBasic.FileIO;
namespace FUE.Web.DataAccess
{
    public class dalTexttoExcel
    {

        public DataTable TxtToDataTable(string sourcefile, string Delimiter)
        {
            var dt = new DataTable();
            try
            {
                if (Delimiter.ToLower() == "tab")
                {
                    var tfp = new TextFieldParser(@"" + sourcefile + "")

                    //var tfp = new TextFieldParser(@"C:\\Test\SampleText.txt")
                    {

                        Delimiters = new[] { "\t" },
                        HasFieldsEnclosedInQuotes = true,
                        TrimWhiteSpace = true
                    };

                    using (tfp)
                    {
                        if (!tfp.EndOfData)
                        {
                            string[] fields = tfp.ReadFields();

                            dt.Columns.AddRange(fields.Select(f => new DataColumn(f)).ToArray());

                            while (!tfp.EndOfData)
                            {
                                fields = tfp.ReadFields();

                                dt.Rows.Add(fields);
                            }
                        }
                    }
                }
                if (Delimiter.ToLower() == "comma")
                {
                    var tfp = new TextFieldParser(@"" + sourcefile + "")

                    //var tfp = new TextFieldParser(@"C:\\Test\SampleText.txt")
                    {

                        Delimiters = new[] { "," },
                        HasFieldsEnclosedInQuotes = true,
                        TrimWhiteSpace = true
                    };

                    using (tfp)
                    {
                        if (!tfp.EndOfData)
                        {
                            string[] fields = tfp.ReadFields();

                            dt.Columns.AddRange(fields.Select(f => new DataColumn(f)).ToArray());

                            while (!tfp.EndOfData)
                            {
                                fields = tfp.ReadFields();

                                dt.Rows.Add(fields);
                            }
                        }
                    }
                }

            }
            catch (Exception)
            {
                throw new Exception("error parsing txt file");
            }
            return dt;
        }
    }
}