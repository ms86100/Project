﻿using FUE.Web.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace FUE.Web.DataAccess
{
    public class EFDBContext: DbContext
    {
       
        public DbSet<utblMstSampleImport> utblMstSampleImports { get; set; }
    }
}