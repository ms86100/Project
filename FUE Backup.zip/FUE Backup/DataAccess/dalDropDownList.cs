﻿using FUE.Web.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.DataAccess
{
    public class dalDropDownList
    {
        EFDBContext _Db = new EFDBContext();

        public List<MstDbConnectionViewModel> GetDbConnectionDDL()
        {
            List<MstDbConnectionViewModel> result = new List<MstDbConnectionViewModel>();

            return result = _Db.Database.SqlQuery<MstDbConnectionViewModel>("select connection_k, catalog +'-'+ type  as catalog from C_DatabaseConnection").ToList();
        }
        public List<MstImportMapHeaderViewModel> GetImportMapHeaderDDL()
        {
            List<MstImportMapHeaderViewModel> result = new List<MstImportMapHeaderViewModel>();

            return result = _Db.Database.SqlQuery<MstImportMapHeaderViewModel>("select importMapHeader_k, importMapName from C_ImportMapHeader").ToList();
        }
        public List<MstActionViewModel> GetActionDDL()
        {
            List<MstActionViewModel> result = new List<MstActionViewModel>();

            return result = _Db.Database.SqlQuery<MstActionViewModel>("select Actions_k, Action from C_Actions").ToList();

            //return result = _db.C_Actions.Select(m => new MstActionViewModel
            //{
            //    actions_k = m.actions_k,
            //    action = m.action
            //}).ToList();


        }
        public List<MstImportJobViewModel> GetImportJobDDL()
        {
            List<MstImportJobViewModel> result = new List<MstImportJobViewModel>();

            return result = _Db.Database.SqlQuery<MstImportJobViewModel>("select import_k, importName from C_ImportJob").ToList();
        }
    }
}