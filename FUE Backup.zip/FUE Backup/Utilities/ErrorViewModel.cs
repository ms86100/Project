﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FUE.Web.Utilities
{
    public class ErrorViewModel
    {
        public int ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
        public decimal? InsertedID { get; set; }
    }
}
