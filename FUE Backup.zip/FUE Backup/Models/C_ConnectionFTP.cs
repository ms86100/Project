﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FUE.Web.Models
{
    public class C_ConnectionFTP
    {
        public int Connection_K { get; set; }
        public string ConnectionName { get; set; }
        public string Url { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }

       
    }
}